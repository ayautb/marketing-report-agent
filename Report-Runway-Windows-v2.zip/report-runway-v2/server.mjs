import http from 'node:http';
import { installWorkflow } from './workflow.mjs';
import { TEAMS } from './domain.mjs';
import { DatabaseSync } from 'node:sqlite';
import { randomBytes, randomUUID, scrypt as derive, timingSafeEqual, createHash } from 'node:crypto';
import { promisify } from 'node:util';
import { mkdirSync, readFileSync, writeFileSync, unlinkSync, chmodSync } from 'node:fs';
import { resolve, join, dirname } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
const scrypt = promisify(derive);
const HERE = dirname(fileURLToPath(import.meta.url));
const ROLES = ['manager', 'leader'];
export const SECTIONS = ['KZ Digital', '4CA Digital', '4CA Retail', 'KZ Retail'];
export const MARKETS = ['KZ', 'MN', 'TJ', 'KG', 'TM', 'ALL'];
export const TYPES = ['Campaign', 'Always-on digital', 'Content', 'Retail / ATL-BTL', 'Other'];
const MAX_FILE = 20 * 1024 * 1024;
const hash = value => createHash('sha256').update(value).digest('hex');
class Failure extends Error { constructor(status, message) { super(message); this.status = status; } }
const fail = (status, message) => { throw new Failure(status, message); };
const string = (value, max = 5000) => typeof value === 'string' && value.length <= max ? value.trim() : fail(400, 'Invalid or overly long field.');
function month(value) { if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(value ?? '')) fail(400, 'Select a valid report month.'); return value; }
function safeLink(value) { if (!value) return ''; try { const url = new URL(value); if (['http:', 'https:'].includes(url.protocol)) return url.href; } catch {} fail(400, 'Materials link must start with https:// or http://.'); }
export async function passwordHash(password) {
  if (typeof password !== 'string' || password.length < 12 || password.length > 128) fail(400, 'Use a password of 12–128 characters.');
  const salt = randomBytes(16).toString('hex');
  return `${salt}:${(await scrypt(password, salt, 64)).toString('hex')}`;
}
async function verify(password, encoded) {
  const [salt, digest] = encoded.split(':');
  if (typeof password !== 'string' || password.length > 128) return false;
  return timingSafeEqual(await scrypt(password, salt, 64), Buffer.from(digest, 'hex'));
}
export function inspectFile(name, mime, bytes) {
  const ext = String(name).split('.').pop()?.toLowerCase();
  const signature = [...bytes.subarray(0, 12)];
  const starts = arr => arr.every((v, i) => signature[i] === v);
  const allowed = {
    png: ['image/png', starts([137,80,78,71,13,10,26,10])],
    jpg: ['image/jpeg', starts([255,216,255])],
    jpeg: ['image/jpeg', starts([255,216,255])],
    webp: ['image/webp', starts([82,73,70,70]) && [87,69,66,80].every((v,i) => signature[i+8] === v)],
    pdf: ['application/pdf', starts([37,80,68,70,45])],
  };
  if (!bytes.length || bytes.length > MAX_FILE) fail(400, 'Each file must be between 1 byte and 20 MB.');
  if (!allowed[ext]?.[1] || (mime && allowed[ext][0] !== mime)) fail(400, 'Use a valid PNG, JPG, WebP or PDF. Export PowerPoint to PDF for slide preview.');
  return { ext, mime: allowed[ext][0] };
}
export function createApplication(options = {}) {
  const dataDir = resolve(options.dataDir ?? process.env.DATA_DIR ?? join(HERE, 'data'));
  mkdirSync(join(dataDir, 'files'), { recursive: true, mode: 0o700 });
  chmodSync(dataDir, 0o700);
  const dbPath = join(dataDir, 'runway.sqlite');
  const db = new DatabaseSync(dbPath); chmodSync(dbPath, 0o600);
  db.exec(`PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON;
    CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY, email TEXT NOT NULL UNIQUE COLLATE NOCASE, name TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN ('viewer','manager','leader')), password TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1, must_change INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS sessions (id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE, csrf TEXT NOT NULL, expires INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS activities (id TEXT PRIMARY KEY, owner_id TEXT REFERENCES users(id), month TEXT NOT NULL, manager TEXT NOT NULL, section TEXT NOT NULL, market TEXT NOT NULL, activity_type TEXT NOT NULL, title TEXT NOT NULL, description TEXT NOT NULL, results TEXT NOT NULL, budget TEXT NOT NULL, link TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS files (id TEXT PRIMARY KEY, owner_id TEXT NOT NULL REFERENCES users(id), activity_id TEXT REFERENCES activities(id) ON DELETE CASCADE, name TEXT NOT NULL, mime TEXT NOT NULL, stored_name TEXT NOT NULL, size INTEGER NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS sends (id TEXT PRIMARY KEY, month TEXT NOT NULL, sender_id TEXT NOT NULL REFERENCES users(id), note TEXT NOT NULL, sent_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS audit (id INTEGER PRIMARY KEY, user_id TEXT, action TEXT NOT NULL, target_id TEXT, at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
    CREATE INDEX IF NOT EXISTS activities_month ON activities(month);
    CREATE INDEX IF NOT EXISTS files_activity ON files(activity_id);
    CREATE INDEX IF NOT EXISTS sessions_user ON sessions(user_id);`);
  const workflow=installWorkflow({db,dataDir,options});
  const origin = options.origin ?? process.env.APP_ORIGIN;
  const secure = origin?.startsWith('https://') ?? false;
  const loginAttempts = new Map();
  const audit = (userId, action, target = '') => db.prepare('INSERT INTO audit(user_id,action,target_id) VALUES (?,?,?)').run(userId, action, target);
  const publicUser = user => ({ id:user.id, name:user.name, email:user.email, role:user.role, team:user.team, must_change:!!user.must_change });
  async function createUser({email, name, role = 'manager', team=null, password, mustChange = true}) {
    email = string(email, 254).toLowerCase(); name = string(name, 120);if(role!=='manager')team=null;
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || !name || !ROLES.includes(role)) fail(400,'Enter a valid email, name and role.');
    if(role==='manager'&&!TEAMS.includes(team))fail(400,'Assign a valid reporting team to the manager.');
    const encoded = await passwordHash(password);
    const id = randomUUID();
    if(role==='manager'&&db.prepare("SELECT id FROM users WHERE team=? AND role='manager' AND active=1").get(team))fail(409,'This team already has an active manager. Disable the previous account before assigning a replacement.');
    try { db.prepare('INSERT INTO users(id,email,name,role,password,must_change,team) VALUES (?,?,?,?,?,?,?)').run(id,email,name,role,encoded,mustChange ? 1 : 0,team); }
    catch (error) { if (error.code?.includes('SQLITE_CONSTRAINT')) fail(409,'This account already exists.'); throw error; }
    return publicUser(db.prepare('SELECT * FROM users WHERE id=?').get(id));
  }
  const dummyPassword = passwordHash(randomBytes(24).toString('hex'));
  const securityHeaders = {
    'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' blob: data:; object-src 'self' blob:; frame-src 'self' blob:; connect-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'self'",
    'X-Content-Type-Options':'nosniff', 'Referrer-Policy':'no-referrer',
    'X-Frame-Options':'SAMEORIGIN', 'Cache-Control':'no-store', 'Cross-Origin-Resource-Policy':'same-origin',
  };
  const json = (res, status, body) => { res.writeHead(status, {...securityHeaders,'Content-Type':'application/json; charset=utf-8'}); res.end(JSON.stringify(body)); };
  async function body(req, limit = 80_000) {
    if (!req.headers['content-type']?.startsWith('application/json')) fail(415,'JSON required.');
    let length=0; const chunks=[];
    for await (const chunk of req) { length += chunk.length; if (length > limit) fail(413,'Request is too large.'); chunks.push(chunk); }
    try { const value=JSON.parse(Buffer.concat(chunks).toString()); if (value === null || Array.isArray(value) || typeof value !== 'object') fail(400,'Invalid request.'); return value; }
    catch (error) { if(error instanceof Failure) throw error; fail(400,'Invalid JSON.'); }
  }
  function auth(req) {
    const raw = /(?:^|;\s*)runway_session=([a-f0-9]{64})(?:;|$)/.exec(req.headers.cookie ?? '')?.[1];
    if (!raw) return null;
    return db.prepare('SELECT u.*, s.csrf, s.id AS session_id FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.id=? AND s.expires>? AND u.active=1').get(hash(raw),Date.now()) ?? null;
  }
  function guard(req, user, write = false, allowed = ROLES) {
    if (!user) fail(401,'Sign in to continue.');
    if (user.must_change && !['/api/password','/api/logout','/api/me'].includes(new URL(req.url, 'http://local').pathname)) fail(403,'Change your temporary password first.');
    if (!allowed.includes(user.role)) fail(403,'Your role does not allow this action.');
    if (write && req.headers['x-csrf-token'] !== user.csrf) fail(403,'Session check failed. Refresh and try again.');
  }
  function cookie(value, ttl=28800) { return `runway_session=${value}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${ttl}${secure ? '; Secure' : ''}`; }
  const server = http.createServer(async (req, res) => {
    try {
      const localPort = server.address()?.port;
      const expected = origin ?? `http://127.0.0.1:${localPort}`;
      if (req.headers.host !== new URL(expected).host) fail(403,'Invalid host.');
      const url = new URL(req.url, expected);
      const route = url.pathname;
      const method = req.method;
      if (!['GET','HEAD'].includes(method) && req.headers.origin !== expected) fail(403,'Cross-origin request blocked.');
      const user = auth(req);
      const setupRequired = !origin && db.prepare('SELECT COUNT(*) AS count FROM users').get().count === 0;
      if (route === '/api/me' && method === 'GET') return json(res,200,{ user: user ? publicUser(user) : null, csrf: user?.csrf ?? null, setupRequired });
      if (route === '/api/setup' && method === 'POST') {
        if(!setupRequired || !['127.0.0.1','::1','::ffff:127.0.0.1'].includes(req.socket.remoteAddress)) fail(403,'Initial setup is not available.');
        const input=await body(req);
        // Serialize initialization across the asynchronous password derivation.
        if(options.initializing) fail(409,'Setup is already in progress.');
        options.initializing=true;
        try {
          if (db.prepare('SELECT COUNT(*) AS count FROM users').get().count !== 0) fail(409,'Workspace is already configured.');
          const account=await createUser({email:input.email,name:input.name,password:input.password,role:'leader',mustChange:false});
          audit(account.id,'initial_setup'); return json(res,201,{ok:true});
        } finally { options.initializing=false; }
      }
      if (route === '/api/login' && method === 'POST') {
        const input = await body(req);
        const key = req.socket.remoteAddress;
        const now = Date.now();
        for (const [k,v] of loginAttempts) if(v.until < now) loginAttempts.delete(k);
        const attempts = loginAttempts.get(key) ?? { count:0, until:now+900_000 };
        if (attempts.count >= 10) fail(429,'Too many attempts. Try again in 15 minutes.');
        attempts.count++; loginAttempts.set(key,attempts);
        const email = string(input.email,254).toLowerCase();
        const account = db.prepare('SELECT * FROM users WHERE email=? AND active=1').get(email);
        const valid = await verify(input.password, account?.password ?? await dummyPassword);
        if (!valid || !account) fail(401,'Email or password is incorrect.');
        loginAttempts.delete(key);
        if(user) db.prepare('DELETE FROM sessions WHERE id=?').run(user.session_id);
        db.prepare('DELETE FROM sessions WHERE expires<?').run(Date.now());
        const token = randomBytes(32).toString('hex'); const csrf = randomBytes(32).toString('hex');
        db.prepare('INSERT INTO sessions(id,user_id,csrf,expires) VALUES (?,?,?,?)').run(hash(token),account.id,csrf,Date.now()+28_800_000);
        audit(account.id,'login'); res.setHeader('Set-Cookie',cookie(token));
        return json(res,200,{user:publicUser(account),csrf});
      }
      if (route === '/api/logout' && method === 'POST') {
        guard(req,user,true); db.prepare('DELETE FROM sessions WHERE id=?').run(user.session_id); res.setHeader('Set-Cookie',cookie('',0)); return json(res,200,{ok:true});
      }
      if (route === '/api/password' && method === 'POST') {
        guard(req,user,true); const input=await body(req);
        if (!await verify(input.currentPassword,user.password)) fail(403,'Current password is incorrect.');
        if (input.currentPassword === input.password) fail(400,'Choose a different password.');
        const encoded=await passwordHash(input.password);
        db.prepare('UPDATE users SET password=?,must_change=0 WHERE id=?').run(encoded,user.id);
        db.prepare('DELETE FROM sessions WHERE user_id=? AND id<>?').run(user.id,user.session_id);
        audit(user.id,'password_changed'); return json(res,200,{ok:true});
      }
      if (route === '/api/users') {
        guard(req,user,method !== 'GET',['leader']);
        if (method === 'GET') return json(res,200,db.prepare('SELECT id,email,name,role,team,active FROM users ORDER BY name').all());
        if (method === 'POST') { const added=await createUser(await body(req)); audit(user.id,'user_created',added.id); return json(res,201,added); }
      }
      if (route.startsWith('/api/users/') && method === 'DELETE') {
        guard(req,user,true,['leader']); const id=route.split('/').pop();
        if (id===user.id) fail(400,'You cannot disable your own account.');
        if(!db.prepare('SELECT id FROM users WHERE id=?').get(id)) fail(404,'User not found.');
        db.prepare('UPDATE users SET active=0 WHERE id=?').run(id); db.prepare('DELETE FROM sessions WHERE user_id=?').run(id);
        audit(user.id,'user_disabled',id); return json(res,200,{ok:true});
      }
      if(await workflow.handle({req,res,route,method,url,user,guard,json,body,securityHeaders,inspectFile}))return;
      if(route.startsWith('/api/')) fail(404,'Endpoint not found.');
      if(method!=='GET' && method!=='HEAD') fail(405,'Method not allowed.');
      if(route.startsWith('/fonts/')){
        const allowed={'/fonts/instrument.ttf':'instrumentsans/InstrumentSans[wdth,wght].ttf','/fonts/instrument-italic.ttf':'instrumentsans/InstrumentSans-Italic[wdth,wght].ttf','/fonts/google.ttf':'googlesans/GoogleSans[GRAD,opsz,wght].ttf'};
        if(!allowed[route])fail(404,'Font not found.');
        res.writeHead(200,{...securityHeaders,'Content-Type':'font/ttf'});return res.end(readFileSync(join(HERE,'fonts',allowed[route])));
      }
      const assets={'/':'index.html','/report':'index.html','/app.js':'app.js','/style.css':'style.css'};
      const asset=assets[route]; if(!asset) fail(404,'Page not found.');
      const mime=asset.endsWith('.js')?'text/javascript':asset.endsWith('.css')?'text/css':'text/html';
      res.writeHead(200,{...securityHeaders,'Content-Type':`${mime}; charset=utf-8`}); res.end(method==='HEAD'?'':readFileSync(join(HERE,'public',asset)));
    } catch (error) { if(!res.headersSent) json(res,error.status ?? 500,{error:error.status ? error.message : 'An unexpected error occurred.',details:error.details??[]}); else res.end(); }
  });
  server.requestTimeout=30_000; server.headersTimeout=15_000;
  return { server, db, createUser, dataDir, workflow, close:async()=>{await workflow.idle();await new Promise(resolveClose=>server.close(()=>{db.close();resolveClose();}));} };
}
if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  const port=Number(process.env.PORT ?? 4317), host=process.env.HOST ?? '127.0.0.1';
  if(host!=='127.0.0.1' && !process.env.APP_ORIGIN?.startsWith('https://')) throw new Error('Internal network deployment requires an explicit HTTPS APP_ORIGIN and TLS reverse proxy.');
  const app=createApplication({recoverJobs:true}); app.server.listen(port,host,()=>console.log(`Report Runway ready: ${process.env.APP_ORIGIN ?? `http://127.0.0.1:${port}`}\nData stays in: ${app.dataDir}`));
  for(const signal of ['SIGTERM','SIGINT']) process.on(signal,()=>void app.close().then(()=>process.exit(0)));
}
