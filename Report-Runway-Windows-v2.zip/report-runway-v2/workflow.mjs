import { randomUUID } from 'node:crypto';
import { mkdirSync,writeFileSync,readFileSync,unlinkSync,existsSync,statSync,readdirSync } from 'node:fs';
import { join,resolve,dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { TEAMS,CHANNELS,LAYOUTS,assertMonth,normalizeProject,validateProject,validatePlan,validateHighlights,defaultPlan,htmlBudget,fingerprint } from './domain.mjs';
const execute=promisify(execFile),HERE=dirname(fileURLToPath(import.meta.url));
const reject=(status,message,details=[])=>{throw Object.assign(new Error(message),{status,details});};
const parse=s=>JSON.parse(s);
export function installWorkflow({db,dataDir,options={}}){
 db.exec(`CREATE TABLE IF NOT EXISTS projects_v2(id TEXT PRIMARY KEY,owner_id TEXT NOT NULL REFERENCES users(id),team TEXT NOT NULL,title TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS updates_v2(id TEXT PRIMARY KEY,project_id TEXT NOT NULL REFERENCES projects_v2(id),month TEXT NOT NULL,data TEXT NOT NULL,revision INTEGER NOT NULL DEFAULT 1,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,UNIQUE(project_id,month));
 CREATE TABLE IF NOT EXISTS plans_v2(owner_id TEXT NOT NULL REFERENCES users(id),month TEXT NOT NULL,data TEXT NOT NULL,PRIMARY KEY(owner_id,month));
 CREATE TABLE IF NOT EXISTS update_files_v2(update_id TEXT NOT NULL REFERENCES updates_v2(id),file_id TEXT NOT NULL REFERENCES files(id),PRIMARY KEY(update_id,file_id));
 CREATE TABLE IF NOT EXISTS builds_v2(id TEXT PRIMARY KEY,owner_id TEXT NOT NULL REFERENCES users(id),month TEXT NOT NULL,kind TEXT NOT NULL,status TEXT NOT NULL,snapshot TEXT NOT NULL,fingerprint TEXT NOT NULL,exact INTEGER NOT NULL DEFAULT 0,slides INTEGER NOT NULL DEFAULT 0,warnings TEXT NOT NULL DEFAULT '[]',error TEXT,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,expires_at TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS submissions_v2(id TEXT PRIMARY KEY,owner_id TEXT NOT NULL REFERENCES users(id),team TEXT NOT NULL,month TEXT NOT NULL,version INTEGER NOT NULL,build_id TEXT NOT NULL UNIQUE REFERENCES builds_v2(id),accepted_at TEXT,accepted_by TEXT REFERENCES users(id),submitted_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,UNIQUE(owner_id,month,version));
 CREATE TABLE IF NOT EXISTS version_files_v2(build_id TEXT NOT NULL REFERENCES builds_v2(id),file_id TEXT NOT NULL REFERENCES files(id),PRIMARY KEY(build_id,file_id));
 CREATE INDEX IF NOT EXISTS v2_updates_month ON updates_v2(month);
 CREATE INDEX IF NOT EXISTS v2_submissions_month ON submissions_v2(month,team);`);
 if(!db.prepare('PRAGMA table_info(users)').all().some(c=>c.name==='team'))db.exec('ALTER TABLE users ADD COLUMN team TEXT');
 if(options.recoverJobs)db.prepare("UPDATE builds_v2 SET status='failed',error='Server restarted during generation. Generate again.' WHERE status IN ('queued','processing')").run();
 mkdirSync(join(dataDir,'builds'),{recursive:true,mode:0o700});
 let queue=Promise.resolve();const log=(user,action,target)=>db.prepare('INSERT INTO audit(user_id,action,target_id) VALUES (?,?,?)').run(user,action,target);
 function ownProjects(user,month){return db.prepare('SELECT p.id,p.team,p.owner_id,u.id AS update_id,u.data,u.revision FROM projects_v2 p JOIN updates_v2 u ON u.project_id=p.id WHERE p.owner_id=? AND u.month=? ORDER BY p.created_at,p.id').all(user.id,month).map(p=>({...p,data:parse(p.data)}));}
 function draft(user,month){const projects=ownProjects(user,month);const stored=db.prepare('SELECT data FROM plans_v2 WHERE owner_id=? AND month=?').get(user.id,month);const plan=stored?parse(stored.data):defaultPlan(projects);return {month,projects,reports:[{team:user.team,ownerId:user.id,projectIds:projects.map(p=>p.id),plan}],sourceVersions:[]};}
 function validate(snapshot){
  const errors=[];if(!snapshot.projects.length)errors.push('Add at least one project.');
  for(const p of snapshot.projects){errors.push(...validateProject(p.data).map(e=>p.data.title+': '+e));for(const image of p.data.groups.flatMap(g=>g.images)){const f=db.prepare('SELECT owner_id,mime FROM files WHERE id=?').get(image.fileId);if(!f||f.owner_id!==p.owner_id||!['image/png','image/jpeg'].includes(f.mime))errors.push('Evidence is unavailable or is not a PNG/JPEG image.');}}
  for(const report of snapshot.reports)errors.push(...validatePlan(report.plan,snapshot.projects.filter(p=>report.projectIds.includes(p.id))));
  errors.push(...validateHighlights(snapshot.projects));
  const budget=htmlBudget(snapshot.projects);if(!budget.fits)errors.push('The HTML exceeds the one-screen budget (10 rows / 1,400 text characters). Reduce selected summary items or next steps.');
  if(errors.length)reject(422,'Complete the report before generating.',errors);
 }
 function canBuild(user,build){return build&&(build.owner_id===user.id||user.role==='leader'&&(build.kind==='release'||!!db.prepare('SELECT id FROM submissions_v2 WHERE build_id=?').get(build.id)));}
 function publicBuild(b){return {id:b.id,month:b.month,kind:b.kind,status:b.status,exact:!!b.exact,slides:b.slides,warnings:parse(b.warnings),error:b.error,created_at:b.created_at,expires_at:b.expires_at};}
 async function generate(id){
  const b=db.prepare('SELECT * FROM builds_v2 WHERE id=?').get(id);if(!b)return;const out=join(dataDir,'builds',id);mkdirSync(out,{recursive:true,mode:0o700});db.prepare("UPDATE builds_v2 SET status='processing' WHERE id=?").run(id);
  try{
   const snapshot=parse(b.snapshot),files={};for(const p of snapshot.projects)for(const img of p.data.groups.flatMap(g=>g.images)){const f=db.prepare('SELECT * FROM files WHERE id=?').get(img.fileId);files[f.id]={path:join(dataDir,'files',f.stored_name),name:f.name};}
   const request={snapshot,files,out,template:join(HERE,'templates','high-technology-gsl.pptx')};
   const input=JSON.stringify(request);const exportReport=(args=[])=>new Promise((ok,no)=>{const child=execFile(options.python??process.env.PYTHON_BIN??'python3',[join(HERE,'export_report.py'),...args],{timeout:120000,maxBuffer:1000000},(error,stdout,stderr)=>error?no(new Error(stderr.trim()||error.message)):ok(stdout));child.stdin.on('error',()=>{});child.stdin.end(input);});await exportReport();
   const manifest=parse(readFileSync(join(out,'manifest.json'),'utf8'));let exact=false;
   const renderer=options.renderCommand??process.env.RENDERER_COMMAND;
   if(renderer){
    await execute(renderer,[join(out,'report.pptx'),join(out,'rendered')],{timeout:120000,maxBuffer:1000000});
    for(let i=1;i<=manifest.slides;i++){const file=join(out,'rendered',`slide-${i}.png`);const bytes=readFileSync(file);if(bytes.length>20*1024*1024||!bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])))throw new Error('The approved renderer did not produce a valid PNG for every slide.');}
    await exportReport(['--html-only']);
    exact=true;
   }
   db.prepare("UPDATE builds_v2 SET status='ready',exact=?,slides=?,warnings=? WHERE id=?").run(exact?1:0,manifest.slides,JSON.stringify(manifest.warnings),id);
  }catch(error){db.prepare("UPDATE builds_v2 SET status='failed',error=? WHERE id=?").run(String(error.message).slice(0,2000),id);}
 }
 function build(user,snapshot,kind){
  validate(snapshot);if(db.prepare("SELECT COUNT(*) AS n FROM builds_v2 WHERE owner_id=? AND status IN ('queued','processing')").get(user.id).n>=2)reject(429,'Two reports are already being prepared. Wait for them to finish.');const id=randomUUID(),expires=new Date(Date.now()+365*86400000).toISOString();db.exec('BEGIN');
  try{db.prepare("INSERT INTO builds_v2(id,owner_id,month,kind,status,snapshot,fingerprint,expires_at) VALUES (?,?,?,?,'queued',?,?,?)").run(id,user.id,snapshot.month,kind,JSON.stringify(snapshot),fingerprint(snapshot),expires);
   for(const fileId of new Set(snapshot.projects.flatMap(p=>p.data.groups.flatMap(g=>g.images.map(i=>i.fileId)))))db.prepare('INSERT INTO version_files_v2(build_id,file_id) VALUES (?,?)').run(id,fileId);
   log(user.id,'build_queued',id);db.exec('COMMIT');
  }catch(e){db.exec('ROLLBACK');throw e;}
  queue=queue.then(()=>generate(id)).catch(()=>{});return id;
 }
 async function handle(ctx){
  const {req,res,route,method,url,user,guard,json,body,securityHeaders,inspectFile}=ctx;
  const send=(code,obj)=>{json(res,code,obj);return true;};const manager=()=>{guard(req,user,method!=='GET',['manager']);if(!TEAMS.includes(user.team))reject(403,'Ask the part leader to assign your reporting team.');};
  if(['/api/activities','/api/sends'].some(p=>route.startsWith(p)))reject(410,'Use the versioned reporting workflow.');
  if(route==='/api/config'){guard(req,user);return send(200,{teams:TEAMS,channels:CHANNELS,layouts:LAYOUTS,deadline:20,retentionDays:365,rendererConfigured:!!(options.renderCommand??process.env.RENDERER_COMMAND),htmlViewport:{width:1080,height:1440},limits:{title:80,text:150,heading:60,subtitle:100,images:6}});}
  if(route==='/api/workspace'&&method==='GET'){
   manager();const month=assertMonth(url.searchParams.get('month'));const snapshot=draft(user,month);const history=db.prepare('SELECT s.*,b.status,b.exact FROM submissions_v2 s JOIN builds_v2 b ON b.id=s.build_id WHERE s.owner_id=? AND s.month=? ORDER BY s.version DESC').all(user.id,month);
   const projects=db.prepare('SELECT id,title,team FROM projects_v2 WHERE owner_id=? ORDER BY created_at DESC').all(user.id);
   return send(200,{...snapshot,plan:snapshot.reports[0].plan,history,allProjects:projects,htmlBudget:htmlBudget(snapshot.projects),validation:snapshot.projects.map(p=>({id:p.id,errors:validateProject(p.data)}))});
  }
  if(route==='/api/projects'&&method==='POST'){
   manager();const input=await body(req),month=assertMonth(input.month);const id=randomUUID();
   const d=normalizeProject(input.data??{});if((input.data?.groups??[]).reduce((n,g)=>n+(g.images?.length??0),0)>6)reject(400,'Maximum 6 images per project.');for(const img of d.groups.flatMap(g=>g.images)){const f=db.prepare('SELECT owner_id FROM files WHERE id=?').get(img.fileId);if(!f||f.owner_id!==user.id)reject(403,'An attachment does not belong to your account.');}db.prepare('INSERT INTO projects_v2(id,owner_id,team,title) VALUES (?,?,?,?)').run(id,user.id,user.team,d.title||'Untitled project');
   const updateId=randomUUID();db.prepare('INSERT INTO updates_v2(id,project_id,month,data) VALUES (?,?,?,?)').run(updateId,id,month,JSON.stringify(d));
   for(const fileId of new Set(d.groups.flatMap(g=>g.images.map(i=>i.fileId))))db.prepare('INSERT INTO update_files_v2(update_id,file_id) VALUES (?,?)').run(updateId,fileId);log(user.id,'project_created',id);return send(201,{id});
  }
  const latest=/^\/api\/projects\/([\w-]+)\/latest$/.exec(route);
  if(latest&&method==='GET'){manager();const p=db.prepare('SELECT id FROM projects_v2 WHERE id=? AND owner_id=?').get(latest[1],user.id);if(!p)reject(404,'Project not found.');const u=db.prepare('SELECT data FROM updates_v2 WHERE project_id=? ORDER BY month DESC LIMIT 1').get(p.id);return send(200,{data:u?parse(u.data):{}});}
  const update=/^\/api\/projects\/([\w-]+)\/months\/(\d{4}-\d{2})$/.exec(route);
  if(update&&['GET','PUT'].includes(method)){
   manager();const p=db.prepare('SELECT * FROM projects_v2 WHERE id=? AND owner_id=?').get(update[1],user.id);if(!p)reject(404,'Project not found.');const month=assertMonth(update[2]);
   if(method==='GET'){const row=db.prepare('SELECT * FROM updates_v2 WHERE project_id=? AND month=?').get(p.id,month);if(!row)reject(404,'There is no update for this month.');return send(200,{id:p.id,data:parse(row.data),revision:row.revision});}
   const input=await body(req);if((input.data?.groups??[]).reduce((n,g)=>n+(g.images?.length??0),0)>6||(input.data?.steps?.length??0)>12||(input.data?.kpis?.length??0)>8)reject(400,'Maximum: 6 images, 12 next steps and 8 KPIs per project.');
   const d=normalizeProject(input.data??{});const prev=db.prepare('SELECT * FROM updates_v2 WHERE project_id=? AND month=?').get(p.id,month);
   if(prev&&input.revision!==prev.revision)reject(409,'This project changed in another window. Reload before saving.');
   const ids=d.groups.flatMap(g=>g.images.map(i=>i.fileId));for(const id of ids){const f=db.prepare('SELECT owner_id FROM files WHERE id=?').get(id);if(!f||f.owner_id!==user.id)reject(403,'An attachment does not belong to your account.');}
   db.exec('BEGIN');try{
    let updateId=prev?.id??randomUUID();if(prev)db.prepare('UPDATE updates_v2 SET data=?,revision=revision+1,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(JSON.stringify(d),updateId);else db.prepare('INSERT INTO updates_v2(id,project_id,month,data) VALUES (?,?,?,?)').run(updateId,p.id,month,JSON.stringify(d));
    db.prepare('UPDATE projects_v2 SET title=? WHERE id=?').run(d.title||p.title,p.id);db.prepare('DELETE FROM update_files_v2 WHERE update_id=?').run(updateId);for(const fileId of new Set(ids))db.prepare('INSERT INTO update_files_v2(update_id,file_id) VALUES (?,?)').run(updateId,fileId);
    log(user.id,'project_updated',updateId);db.exec('COMMIT');
   }catch(error){db.exec('ROLLBACK');throw error;}
   return send(200,{ok:true,revision:(prev?.revision??0)+1,errors:validateProject(d)});
  }
  if(route==='/api/plan'&&method==='PUT'){
   manager();const input=await body(req);const month=assertMonth(input.month);const projects=ownProjects(user,month);const errors=validatePlan(input.plan,projects);if(errors.length)reject(422,'Fix the slide plan.',errors);
   db.prepare('INSERT INTO plans_v2(owner_id,month,data) VALUES (?,?,?) ON CONFLICT(owner_id,month) DO UPDATE SET data=excluded.data').run(user.id,month,JSON.stringify(input.plan));return send(200,{ok:true});
  }
  if(route==='/api/builds'&&method==='POST'){manager();const input=await body(req);const snapshot=draft(user,assertMonth(input.month));return send(202,{id:build(user,snapshot,'manager')});}
  const bm=/^\/api\/builds\/([\w-]+)(?:\/(.+))?$/.exec(route);
  if(bm){
   guard(req,user,method!=='GET');const b=db.prepare('SELECT * FROM builds_v2 WHERE id=?').get(bm[1]);if(!canBuild(user,b))reject(404,'Report not found.');
   if(!bm[2]&&method==='GET')return send(200,{...publicBuild(b),snapshot:parse(b.snapshot)});
   if(bm[2]==='submit'&&method==='POST'){
    manager();const input=await body(req);if(b.status!=='ready'||!b.exact)reject(409,'Final submission needs an approved server renderer and exact PPTX preview.');if(!input.htmlFits)reject(422,'Check that the HTML fits the reference screen.');if(!input.confirmed)reject(422,'Confirm that you checked every slide and the HTML.');
    if(fingerprint(draft(user,b.month))!==b.fingerprint)reject(409,'The draft changed after preview. Generate and check it again.');
    if(db.prepare('SELECT id FROM submissions_v2 WHERE build_id=?').get(b.id))reject(409,'This version was already submitted.');
    const version=db.prepare('SELECT COALESCE(MAX(version),0)+1 AS v FROM submissions_v2 WHERE owner_id=? AND month=?').get(user.id,b.month).v;const id=randomUUID();db.prepare('INSERT INTO submissions_v2(id,owner_id,team,month,version,build_id) VALUES (?,?,?,?,?,?)').run(id,user.id,user.team,b.month,version,b.id);log(user.id,'report_submitted',id);return send(201,{id,version});
   }
   if(method==='GET'){
    if(b.status!=='ready')reject(409,'The report is not ready.');const files={'report.pptx':['application/vnd.openxmlformats-officedocument.presentationml.presentation','attachment'],'summary.html':['text/html; charset=utf-8','attachment'],'email.html':['text/html; charset=utf-8','attachment'],'view.html':['text/html; charset=utf-8','inline']};
    let file,mime,disposition='inline';
    if(files[bm[2]]){file=join(dataDir,'builds',b.id,bm[2]==='view.html'?'summary.html':bm[2]);[mime,disposition]=files[bm[2]];}
    else if(/^slides\/\d+$/.test(bm[2])){const n=Number(bm[2].split('/')[1]);if(n<1||n>b.slides)reject(404,'Slide not found.');file=join(dataDir,'builds',b.id,b.exact?'rendered':'preview',`slide-${n}.${b.exact?'png':'svg'}`);mime=b.exact?'image/png':'image/svg+xml';}
    else reject(404,'File not found.');
    const bytes=readFileSync(file);res.writeHead(200,{...securityHeaders,'Content-Security-Policy':"sandbox allow-same-origin; default-src 'none'; img-src data:; font-src data:; style-src 'unsafe-inline'",'Content-Type':mime,'Content-Length':bytes.length,'Content-Disposition':`${disposition}; filename="${bm[2]==='view.html'?'summary.html':bm[2].split('/').pop()}"`});res.end(bytes);return true;
   }
  }
  if(route==='/api/submissions'&&method==='GET'){
   guard(req,user);const month=assertMonth(url.searchParams.get('month'));let rows=db.prepare('SELECT s.*,u.name,b.exact,b.status,b.slides FROM submissions_v2 s JOIN users u ON u.id=s.owner_id JOIN builds_v2 b ON b.id=s.build_id WHERE s.month=? ORDER BY s.submitted_at DESC,s.version DESC').all(month);if(user.role!=='leader')rows=rows.filter(r=>r.owner_id===user.id);return send(200,rows);
  }
  const accept=/^\/api\/submissions\/([\w-]+)\/accept$/.exec(route);
  if(accept&&method==='POST'){
   guard(req,user,true,['leader']);const s=db.prepare('SELECT * FROM submissions_v2 WHERE id=?').get(accept[1]);if(!s)reject(404,'Version not found.');const newer=db.prepare('SELECT id FROM submissions_v2 WHERE owner_id=? AND month=? AND version>?').get(s.owner_id,s.month,s.version);if(newer)reject(409,'A newer version is waiting. Accept the newest submitted version.');db.prepare("UPDATE submissions_v2 SET accepted_at=strftime('%Y-%m-%d %H:%M:%f','now'),accepted_by=? WHERE id=?").run(user.id,s.id);log(user.id,'report_accepted',s.id);return send(200,{ok:true});
  }
  if(route==='/api/releases'){
   guard(req,user,method!=='GET',['leader']);if(method==='GET'){const month=assertMonth(url.searchParams.get('month'));return send(200,db.prepare("SELECT * FROM builds_v2 WHERE month=? AND kind='release' ORDER BY created_at DESC").all(month).map(publicBuild));}
   if(method==='POST'){
    const input=await body(req);const month=assertMonth(input.month);const snapshot={month,projects:[],reports:[],missing:[],sourceVersions:[]};const pending=[];
    for(const team of TEAMS){const accepted=db.prepare('SELECT s.*,b.snapshot FROM submissions_v2 s JOIN builds_v2 b ON b.id=s.build_id WHERE s.team=? AND s.month=? AND s.accepted_at IS NOT NULL ORDER BY s.accepted_at DESC,s.submitted_at DESC,s.version DESC LIMIT 1').get(team,month);
     if(!accepted){snapshot.missing.push(team);continue;}const data=parse(accepted.snapshot);snapshot.projects.push(...data.projects);snapshot.reports.push(...data.reports);snapshot.sourceVersions.push(team+' V'+accepted.version+' ('+accepted.id+')');
     const newer=db.prepare('SELECT id FROM submissions_v2 WHERE team=? AND month=? AND submitted_at>=? AND accepted_at IS NULL').get(team,month,accepted.submitted_at);if(newer)pending.push(team);
    }
    const id=build(user,snapshot,'release');return send(202,{id,missing:snapshot.missing,pending});
   }
  }
  if(route==='/api/files'&&method==='POST'){
   manager();const input=await body(req,29000000);const name=String(input.name??'').replace(/[\x00-\x1f\x7f]/g,'').slice(0,200);if(!name||typeof input.base64!=='string'||!/^[A-Za-z0-9+/]*={0,2}$/.test(input.base64)||input.base64.length%4)reject(400,'Invalid image.');const bytes=Buffer.from(input.base64,'base64');const total=db.prepare('SELECT COALESCE(SUM(size),0) AS n FROM files WHERE owner_id=?').get(user.id).n;if(total+bytes.length>1024*1024*1024)reject(413,'The account storage limit is 1 GB. Ask the administrator to review retention.');const pending=db.prepare('SELECT COUNT(*) AS n FROM files f WHERE owner_id=? AND NOT EXISTS (SELECT 1 FROM update_files_v2 u WHERE u.file_id=f.id) AND NOT EXISTS (SELECT 1 FROM version_files_v2 v WHERE v.file_id=f.id)').get(user.id).n;if(pending>=20)reject(409,'Too many unattached uploads. Save or remove unused images first.');const info=inspectFile(name,input.mime??'',bytes);if(!['image/png','image/jpeg'].includes(info.mime))reject(400,'Use PNG or JPEG evidence. Export charts as images or use the editable KPI chart option.');const id=randomUUID(),stored=id+'.'+info.ext;writeFileSync(join(dataDir,'files',stored),bytes,{mode:0o600,flag:'wx'});try{db.prepare('INSERT INTO files(id,owner_id,name,mime,stored_name,size) VALUES (?,?,?,?,?,?)').run(id,user.id,name,info.mime,stored,bytes.length);}catch(e){unlinkSync(join(dataDir,'files',stored));throw e;}return send(201,{id,name,mime:info.mime,size:bytes.length});
  }
  const fm=/^\/api\/files\/([\w-]+)$/.exec(route);
  if(fm){
   guard(req,user,method==='DELETE');const f=db.prepare('SELECT * FROM files WHERE id=?').get(fm[1]);const submitted=f&&db.prepare('SELECT vf.file_id FROM version_files_v2 vf JOIN submissions_v2 s ON s.build_id=vf.build_id WHERE vf.file_id=?').get(f.id);if(!f||(f.owner_id!==user.id&&!(user.role==='leader'&&submitted)))reject(404,'File not found.');
   if(method==='DELETE'){if(f.owner_id!==user.id||db.prepare('SELECT file_id FROM version_files_v2 WHERE file_id=?').get(f.id)||db.prepare('SELECT file_id FROM update_files_v2 WHERE file_id=?').get(f.id))reject(409,'This image belongs to a draft or saved version.');db.prepare('DELETE FROM files WHERE id=?').run(f.id);unlinkSync(join(dataDir,'files',f.stored_name));return send(200,{ok:true});}
   if(method==='GET'){const bytes=readFileSync(join(dataDir,'files',f.stored_name));res.writeHead(200,{...securityHeaders,'Content-Type':f.mime,'Content-Length':bytes.length});res.end(bytes);return true;}
  }
  return false;
 }
 return {handle,idle:()=>queue,draft,validate,generate};
}
