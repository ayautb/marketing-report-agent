name: "Google Sans"
designer: "Google"
license: "OFL"
category: "SANS_SERIF"
date_added: "2017-06-05"
fonts {
  name: "Google Sans"
  style: "normal"
  weight: 400
  filename: "GoogleSans[GRAD,opsz,wght].ttf"
  post_script_name: "GoogleSans-Regular"
  full_name: "Google Sans Regular"
  copyright: "Copyright 2025 The Google Sans Project Authors (github.com/googlefonts/googlesans)"
}
fonts {
  name: "Google Sans"
  style: "italic"
  weight: 400
  filename: "GoogleSans-Italic[GRAD,opsz,wght].ttf"
  post_script_name: "GoogleSans-Italic"
  full_name: "Google Sans Italic"
  copyright: "Copyright 2025 The Google Sans Project Authors (github.com/googlefonts/googlesans)"
}
subsets: "arabic"
subsets: "armenian"
subsets: "bengali"
subsets: "canadian-aboriginal"
subsets: "cyrillic"
subsets: "cyrillic-ext"
subsets: "devanagari"
subsets: "ethiopic"
subsets: "georgian"
subsets: "greek"
subsets: "greek-ext"
subsets: "gujarati"
subsets: "gurmukhi"
subsets: "hebrew"
subsets: "kannada"
subsets: "khmer"
subsets: "lao"
subsets: "latin"
subsets: "latin-ext"
subsets: "malayalam"
subsets: "menu"
subsets: "oriya"
subsets: "sinhala"
subsets: "symbols"
subsets: "tamil"
subsets: "telugu"
subsets: "thai"
subsets: "vietnamese"
axes {
  tag: "GRAD"
  min_value: -50.0
  max_value: 200.0
}
axes {
  tag: "opsz"
  min_value: 17.0
  max_value: 18.0
}
axes {
  tag: "wght"
  min_value: 400.0
  max_value: 700.0
}
registry_default_overrides {
  key: "opsz"
  value: 18
}
source {
  repository_url: "https://github.com/googlefonts/googlesans"
  commit: "5c8f512c5fb42a7be099b951a7c097f96209c78e"
  archive_url: "https://github.com/googlefonts/googlesans/releases/download/v14.000/GoogleSans-v14.000.zip"
  config_yaml: "sources/config.yaml"
  files {
    source_file: "build/GoogleSans/variable/GoogleSans[GRAD,opsz,wght].ttf"
    dest_file: "GoogleSans[GRAD,opsz,wght].ttf"
  }
  files {
    source_file: "build/GoogleSans/variable/GoogleSans-Italic[GRAD,opsz,wght].ttf"
    dest_file: "GoogleSans-Italic[GRAD,opsz,wght].ttf"
  }
  branch: "main"
}
