#!/usr/bin/env python3
"""Approximate OOXML preview for draft inspection. Never certifies Office parity."""
import json,zipfile,xml.etree.ElementTree as E,sys,re,posixpath,base64,html,math,textwrap
from pathlib import Path
A='http://schemas.openxmlformats.org/drawingml/2006/main';P='http://schemas.openxmlformats.org/presentationml/2006/main';R='http://schemas.openxmlformats.org/officeDocument/2006/relationships';N={'a':A,'p':P};U=12700
esc=lambda x:html.escape(str(x),quote=True)
def color(el,default='#fff'):
 if el is None:return default
 c=el.find('.//a:srgbClr',N)
 if c is not None:return '#'+c.get('val','ffffff')
 c=el.find('.//a:schemeClr',N)
 if c is not None:return {'dk1':'#000000','lt1':'#ffffff','accent1':'#477edb','accent2':'#7bc9ec','tx1':'#ffffff','bg1':'#000000'}.get(c.get('val'),default)
 return default
def main(pptx,out,font):
 z=zipfile.ZipFile(pptx);out=Path(out);out.mkdir(parents=True,exist_ok=True)
 fontdata=base64.b64encode(Path(font).read_bytes()).decode();names=sorted([n for n in z.namelist() if re.fullmatch(r'ppt/slides/slide\d+.xml',n)],key=lambda n:int(re.search(r'(\d+)\.xml',n).group(1)))
 for page,name in enumerate(names,1):
  root=E.fromstring(z.read(name));rels=E.fromstring(z.read(posixpath.dirname(name)+'/_rels/'+posixpath.basename(name)+'.rels'));targets={r.get('Id'):posixpath.normpath(posixpath.join('ppt/slides',r.get('Target',''))) for r in rels};defs=[];seq=[0]
  layout=next((targets[r.get('Id')] for r in rels if r.get('Type','').endswith('/slideLayout')),None);layoutroot=E.fromstring(z.read(layout)) if layout in z.namelist() else None
  def inherited(el,path):
   found=el.find(path,N)
   if found is not None:return found
   ph=el.find('.//p:ph',N)
   if ph is not None and layoutroot is not None:
    for candidate in list(layoutroot.findall('.//p:sp',N))+list(layoutroot.findall('.//p:pic',N)):
     cp=candidate.find('.//p:ph',N)
     if cp is not None and cp.get('idx')==ph.get('idx'):return candidate.find(path,N)
   return None
  def draw(el):
   kind=el.tag.split('}')[-1]
   if kind not in ['sp','pic','grpSp','graphicFrame']:return ''
   if kind=='grpSp':
    xf=el.find('p:grpSpPr/a:xfrm',N)
    if xf is None:return ''.join(draw(c) for c in el)
    o=xf.find('a:off',N);e=xf.find('a:ext',N);co=xf.find('a:chOff',N);ce=xf.find('a:chExt',N)
    if any(v is None for v in [o,e,co,ce]):return ''.join(draw(c) for c in el)
    sx=float(e.get('cx'))/max(1,float(ce.get('cx')));sy=float(e.get('cy'))/max(1,float(ce.get('cy')))
    return '<g transform="translate(%s,%s) scale(%s,%s) translate(%s,%s)">'%(float(o.get('x'))/U,float(o.get('y'))/U,sx,sy,-float(co.get('x'))/U,-float(co.get('y'))/U)+''.join(draw(c) for c in el)+'</g>'
   xf=inherited(el,'p:spPr/a:xfrm')
   if xf is None:xf=el.find('p:xfrm',N)
   if xf is None:return ''
   o=xf.find('a:off',N);e=xf.find('a:ext',N)
   if o is None or e is None:return ''
   x,y,w,h=[float(v)/U for v in [o.get('x','0'),o.get('y','0'),e.get('cx','0'),e.get('cy','0')]]
   rot=float(xf.get('rot','0'))/60000;transform='rotate(%s %s %s)'%(rot,x+w/2,y+h/2)
   seq[0]+=1;ident='s'+str(seq[0]);content=''
   if kind=='pic':
    blip=el.find('.//a:blip',N);target=targets.get(blip.get('{'+R+'}embed')) if blip is not None else None
    if target and target in z.namelist():
     mime='image/png' if target.lower().endswith('.png') else 'image/jpeg';data=base64.b64encode(z.read(target)).decode();defs.append('<clipPath id="%s"><rect x="%s" y="%s" width="%s" height="%s" rx="3"/></clipPath>'%(ident,x,y,w,h));crop=el.find('.//a:srcRect',N);l=t=r=b=0
     if crop is not None:l,t,r,b=[float(crop.get(k,'0'))/100000 for k in ['l','t','r','b']]
     iw=w/max(.01,1-l-r);ih=h/max(.01,1-t-b)
     content='<image x="%s" y="%s" width="%s" height="%s" preserveAspectRatio="none" clip-path="url(#%s)" href="data:%s;base64,%s"/>'%(x-l*iw,y-t*ih,iw,ih,ident,mime,data)
   elif kind=='graphicFrame':content='<rect x="%s" y="%s" width="%s" height="%s" fill="#123568"/><text x="%s" y="%s" fill="white" font-size="14">Editable KPI chart · see PPTX</text>'%(x,y,w,h,x+5,y+22)
   else:
    pr=el.find('p:spPr',N);fill='none';stroke='none'
    if pr is not None:
     solid=pr.find('a:solidFill',N);grad=pr.find('a:gradFill',N)
     if solid is not None:fill=color(solid)
     if grad is not None:
      gid=ident+'g';stops=[]
      for gs in grad.findall('a:gsLst/a:gs',N):stops.append('<stop offset="%s%%" stop-color="%s"/>'%(float(gs.get('pos'))/1000,color(gs)))
      defs.append('<linearGradient id="%s" x1="0" y1="0" x2="1" y2="1">%s</linearGradient>'%(gid,''.join(stops)));fill='url(#'+gid+')'
     line=pr.find('a:ln',N)
     if line is not None and line.find('a:noFill',N) is None:stroke=color(line,'#3459b8')
    geom=pr.find('a:prstGeom',N) if pr is not None else None;radius=8 if geom is not None and geom.get('prst') in ['roundRect','round2SameRect'] else 0
    if fill!='none' or stroke!='none':content+='<rect x="%s" y="%s" width="%s" height="%s" rx="%s" fill="%s" stroke="%s"/>'%(x,y,w,h,radius,fill,stroke)
    body=el.find('p:txBody',N)
    if body is not None:
     yy=y+3
     for para in body.findall('a:p',N):
      runs=para.findall('a:r',N);ppr=para.find('a:pPr',N);align=ppr.get('algn','l') if ppr is not None else 'l';value=''.join(n.text or '' for n in para.findall('.//a:t',N));rp=runs[0].find('a:rPr',N) if runs else para.find('a:endParaRPr',N);size=float(rp.get('sz','1600'))/100 if rp is not None else 16;ink=color(rp);weight='700' if rp is not None and rp.get('b')=='1' else '400';maxchars=max(1,int(max(w,40)/(size*.49)));lines=textwrap.wrap(value,maxchars,break_long_words=True) or [''];anchor='middle' if align=='ctr' else 'end' if align=='r' else 'start';xx=x+w/2 if anchor=='middle' else x+w if anchor=='end' else x
      for line in lines:yy+=size*1.15;content+='<text x="%s" y="%s" font-family="Instrument Sans" font-size="%s" font-weight="%s" fill="%s" text-anchor="%s">%s</text>'%(xx,yy,size,weight,ink,anchor,esc(line))
   return '<g transform="'+transform+'">'+content+'</g>'
  body=''.join(draw(c) for c in root.find('p:cSld/p:spTree',N));svg='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 960 540"><defs><style>@font-face{font-family:"Instrument Sans";src:url(data:font/ttf;base64,'+fontdata+')}</style>'+''.join(defs)+'</defs><rect width="960" height="540" fill="#000"/>'+body+'</svg>';(out/('slide-%d.svg'%page)).write_text(svg)
 print(json.dumps({'slides':len(names),'exact':False}))
if __name__=='__main__':main(*sys.argv[1:])
