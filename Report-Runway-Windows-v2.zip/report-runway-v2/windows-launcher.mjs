import {spawnSync} from 'node:child_process';
import {dirname,join,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';

const HERE=dirname(fileURLToPath(import.meta.url));
const PYTHON_PROBE='import sys,json; print(json.dumps({"executable":sys.executable,"version":list(sys.version_info[:3])}))';

export function findPython(env=process.env,run=spawnSync){
 const candidates=env.PYTHON_BIN?[[env.PYTHON_BIN,[]]]:[['py',['-3']],['python',[]],['python3',[]]];
 for(const [command,args] of candidates){
  const result=run(command,[...args,'-c',PYTHON_PROBE],{encoding:'utf8',windowsHide:true,timeout:15000,env});
  if(result.error||result.status!==0)continue;
  try{
   const info=JSON.parse(result.stdout.trim());
   if(typeof info.executable!=='string'||!info.executable||!Array.isArray(info.version)||info.version[0]<3||(info.version[0]===3&&info.version[1]<9))continue;
   // Use the real executable, so the exporter needs no launcher flags or shell quoting.
   return info.executable;
  }catch{}
 }
 return null;
}

export function launch({env=process.env,run=spawnSync,nodeVersion=process.versions.node,node=process.execPath}={}){
 if(Number(nodeVersion.split('.')[0])<24){console.error('Node.js 24 or later is required. Ask IT to update Node.js.');return 1;}
 const python=findPython(env,run);
 if(!python){console.error('Python 3.9 or later is required. Ask IT to install Python, then reopen Start.bat.');if(env.PYTHON_BIN)console.error('The configured PYTHON_BIN must point to a working Python executable.');return 1;}
 console.log('Starting Report Runway. Keep this window open; Ctrl+C stops the app.');
 const result=run(node,[join(HERE,'server.mjs')],{cwd:HERE,env:{...env,PYTHON_BIN:python},stdio:'inherit',windowsHide:false});
 if(result.error){console.error('Could not start the application: '+result.error.message);return 1;}
 return result.status??1;
}

if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url))process.exitCode=launch();
