import { createHash } from 'node:crypto';
export const TEAMS=['KZ ATL/BTL','4CA Marketing','KZ Retail'];
export const CHANNELS=['Digital','Retail','Trade','Affiliate','ATL','BTL','Other'];
export const LAYOUTS={promo:{name:'Promo & KPI',slide:4,capacity:1,images:3},content:{name:'Grouped content',slide:5,capacity:3,images:6},launch:{name:'Launch & activities',slide:6,capacity:1,images:4},pipeline:{name:'Retail pipeline',slide:8,capacity:8,images:0},collage:{name:'Evidence collage',slide:9,capacity:6,images:6},retail:{name:'Retail project detail',slide:12,capacity:1,images:5},models:{name:'Premium / Step Up',slide:3,capacity:2,images:4}};
export const fingerprint=value=>createHash('sha256').update(JSON.stringify(value)).digest('hex');
export function assertMonth(value){if(!/^\d{4}-(0[1-9]|1[0-2])$/.test(value??''))throw Object.assign(new Error('Choose a valid report month.'),{status:400});return value;}
const text=(value,max=150)=>typeof value==='string'&&[...value].length<=max?value.trim():'';
export function normalizeProject(input){
 const value={};for(const key of ['title','category','partner','partnerNote','goal','done','conclusion','start','end','retailStatus','retailStage','productFocus'])value[key]=text(input[key]);
 value.title=text(input.title,80);value.market=text(input.market,30);value.channels=Array.isArray(input.channels)?[...new Set(input.channels.filter(c=>CHANNELS.includes(c)))]:[];
 value.budget={plan:text(input.budget?.plan,30),actual:text(input.budget?.actual,30),currency:text(input.budget?.currency,10)};
 value.summary=!!input.summary;value.next=!!input.next;value.summaryText=text(input.summaryText);
 value.steps=(Array.isArray(input.steps)?input.steps:[]).slice(0,12).map(s=>({action:text(s.action),owner:text(s.owner,60),due:text(s.due,10)}));
 value.kpis=(Array.isArray(input.kpis)?input.kpis:[]).slice(0,8).map(k=>({name:text(k.name,50),plan:k.plan===''||k.plan===null?null:Number(k.plan),actual:k.actual===''||k.actual===null?null:Number(k.actual),unit:text(k.unit,20)}));
 value.groups=(Array.isArray(input.groups)?input.groups:[]).slice(0,6).map(g=>({id:text(g.id,80),heading:text(g.heading,60),subtitle:text(g.subtitle,100),images:(Array.isArray(g.images)?g.images:[]).slice(0,6).map(img=>({fileId:text(img.fileId,80),mode:['contain','cover','manual'].includes(img.mode)?img.mode:'contain',crop:Object.fromEntries(['left','top','right','bottom'].map(k=>[k,Math.max(0,Math.min(0.95,Number(img.crop?.[k])||0))]))}))}));
 value.editableChart=!!input.editableChart;
 return value;
}
export function validateProject(p){
 const errors=[];for(const key of ['title','market','category','partner','goal','start','end','done','conclusion'])if(!p[key])errors.push(`${key}: required (maximum 150 characters; title 80).`);
 const date=v=>/^\d{4}-\d{2}-\d{2}$/.test(v)&&!Number.isNaN(Date.parse(v))&&new Date(v).toISOString().slice(0,10)===v;
 if(!date(p.start)||!date(p.end)||p.start>p.end)errors.push('Enter a valid start and end date.');
 if(!p.channels.length)errors.push('Choose at least one channel.');
 if(p.partner==='N/A'&&!p.partnerNote)errors.push('Explain why the partner is N/A.');
 if(p.channels.includes('Retail')){
  if(!['Planned','In progress','Completed'].includes(p.retailStatus))errors.push('Retail status is required.');
  if(!['Design','Bidding','Production','Installed'].includes(p.retailStage))errors.push('Retail implementation stage is required.');
 }
 if(p.channels.some(c=>['Trade','Affiliate'].includes(c))&&!p.kpis.length)errors.push('Trade and Affiliate require at least one KPI.');
 for(const k of p.kpis)if(!k.name||!k.unit||k.plan===null||k.actual===null||!Number.isFinite(k.plan)||!Number.isFinite(k.actual))errors.push('Each KPI needs a name, finite plan and actual, and unit.');
 if(p.editableChart&&new Set(p.kpis.map(k=>k.unit)).size>1)errors.push('Use one unit of measurement in an editable KPI chart, or attach separate chart images.');
 if(p.editableChart&&!p.kpis.length)errors.push('An editable chart needs KPI values.');
 if(!p.steps.length)errors.push('At least one next step is required.');
 for(const s of p.steps)if(!s.action||!s.owner||!date(s.due))errors.push('Each next step needs an action, owner and valid due date.');
 const images=p.groups.flatMap(g=>g.images);if(images.length<1||images.length>6)errors.push('Attach between 1 and 6 evidence images per project.');
 if(new Set(images.map(i=>i.fileId)).size!==images.length)errors.push('Do not repeat the same evidence image within a project.');
 for(const g of p.groups)if(g.images.length&&(!g.heading||!g.subtitle))errors.push('Every evidence group needs one heading and subtitle.');
 for(const img of images)if(img.mode==='manual'&&(img.crop.left+img.crop.right>=1||img.crop.top+img.crop.bottom>=1))errors.push('The crop must leave part of the image visible.');
 if(p.summary&&!p.summaryText)errors.push('Selected summary projects need a key highlight.');
 return [...new Set(errors)];
}
export function defaultPlan(projects){return projects.map(p=>({layout:p.data.channels.includes('Retail')?'collage':p.data.kpis.length?'promo':'content',projectIds:[p.id]}));}
export function validatePlan(plan,projects){
 const errors=[];const ids=new Set(projects.map(p=>p.id));const covered=new Set();
 if(!Array.isArray(plan)||!plan.length||plan.length>120)return ['Choose 1–120 slides.'];
 for(const slide of plan){const l=LAYOUTS[slide.layout];if(!l||!Array.isArray(slide.projectIds)||!slide.projectIds.length){errors.push('Each slide needs a layout and projects.');continue;}
 if(slide.projectIds.length>l.capacity)errors.push(`${l.name}: maximum ${l.capacity} projects per slide.`);
 for(const id of slide.projectIds){if(!ids.has(id))errors.push('A slide refers to an unavailable project.');else covered.add(id);}
 if(slide.layout==='pipeline'&&slide.projectIds.some(id=>!projects.find(p=>p.id===id)?.data.channels.includes('Retail')))errors.push('The pipeline layout is available only for Retail projects.');
 }
 for(const id of ids)if(!covered.has(id))errors.push('Every project in this month must appear on a slide.');
 return [...new Set(errors)];
}
export function htmlBudget(projects){
 const summaries=projects.filter(p=>p.data.summary);const steps=projects.filter(p=>p.data.next).flatMap(p=>p.data.steps);
 const chars=summaries.reduce((n,p)=>n+p.data.title.length+p.data.done.length+p.data.summaryText.length,0)+steps.reduce((n,s)=>n+s.action.length+s.owner.length,0);
 return {summaryRows:summaries.length,nextRows:steps.length,chars,fits:summaries.length+steps.length<=10&&chars<=1400};
}
export function validateHighlights(projects){
 const errors=[];
 for(const team of TEAMS)for(const flag of ['summary','next'])if(projects.filter(p=>p.team===team&&p.data[flag]).length>1)errors.push(`${team}: select only one main project for ${flag==='summary'?'Executive summary':'Next steps'}.`);
 for(const p of projects.filter(p=>p.data.next))if(p.data.steps.map(s=>`${s.action}\n${s.owner} · ${s.due}`).join('\n').length>150)errors.push(`${p.data.title}: shorten the selected next steps to 150 characters in total to fit the single final slide.`);
 return errors;
}
