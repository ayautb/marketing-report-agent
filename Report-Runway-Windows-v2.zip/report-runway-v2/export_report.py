#!/usr/bin/env python3
"""Fill the original OOXML slides without rebuilding their visible design.
Standard-library only. Source sibling order, groups, media, theme and layouts are retained.
SVG previews are an inspection fallback, NOT certified PowerPoint rendering.
"""
import io,sys,json,zipfile,copy,re,posixpath,base64,html,struct,math,textwrap
from pathlib import Path
import xml.etree.ElementTree as E
P='http://schemas.openxmlformats.org/presentationml/2006/main';A='http://schemas.openxmlformats.org/drawingml/2006/main';R='http://schemas.openxmlformats.org/officeDocument/2006/relationships';PK='http://schemas.openxmlformats.org/package/2006/relationships';C='http://schemas.openxmlformats.org/drawingml/2006/chart';CT='http://schemas.openxmlformats.org/package/2006/content-types'
NS={'p':P,'a':A,'r':R,'c':C};EMU=12700
for prefix,url in [('p',P),('a',A),('r',R),('c',C)]:E.register_namespace(prefix,url)
def tag(ns,name):return '{'+ns+'}'+name
def xml(el):return E.tostring(el,encoding='utf-8',xml_declaration=True)
def txt(el):return ''.join(n.text or '' for n in el.findall('.//a:t',NS))
def norm(s):return ' '.join(s.split()).lower()
def spid(el):
 p=el.find('.//p:cNvPr',NS);return p.get('id') if p is not None else ''
def set_text(el,value):
 body=el.find('p:txBody',NS)
 if body is None:return
 paragraphs=body.findall('a:p',NS);first=paragraphs[0] if paragraphs else E.SubElement(body,tag(A,'p'))
 ppr=copy.deepcopy(first.find('a:pPr',NS));end=copy.deepcopy(first.find('a:endParaRPr',NS))
 source_runs=[(copy.deepcopy(r.find('a:rPr',NS)),r.findtext('a:t','',NS)) for r in first.findall('a:r',NS)]
 if not source_runs:source_runs=[(copy.deepcopy(end) if end is not None else E.Element(tag(A,'rPr'),{'lang':'en-US','sz':'1600'}),'')]
 for p in paragraphs:body.remove(p)
 for line in str(value).split('\n'):
  p=E.SubElement(body,tag(A,'p'))
  if ppr is not None:p.append(copy.deepcopy(ppr))
  words=re.findall(r'\S+\s*',line);used=0
  for i,(style,oldtext) in enumerate(source_runs):
   if i==len(source_runs)-1:piece=''.join(words[used:])
   else:
    remaining=sum(1 for style,text in source_runs[i+1:] if text.strip());count=min(len(re.findall(r'\S+',oldtext)),max(0,len(words)-used-remaining));piece=''.join(words[used:used+count]);used+=count
   r=E.SubElement(p,tag(A,'r'))
   if style is not None:
    cloned=copy.deepcopy(style);cloned.tag=tag(A,'rPr');r.append(cloned)
   E.SubElement(r,tag(A,'t')).text=piece
  if end is not None:p.append(copy.deepcopy(end))
 for n in body.iter():
  for h in list(n):
   if h.tag in [tag(A,'hlinkClick'),tag(A,'hlinkMouseOver')]:n.remove(h)
def shapes(root):return root.findall('.//p:sp',NS)
def replace(root,needle,values):
 if isinstance(values,str):values=[values]
 found=[s for s in shapes(root) if norm(txt(s))==norm(needle)]
 for i,s in enumerate(found):set_text(s,values[i] if i<len(values) else '')
def replace_regex(root,pattern,value):
 for s in shapes(root):
  if re.match(pattern,txt(s),re.I):set_text(s,value)
def geometry(el):
 x=el.find('p:spPr/a:xfrm',NS)
 if x is None:x=el.find('p:grpSpPr/a:xfrm',NS)
 if x is None:return (0,0,0,0)
 off=x.find('a:off',NS);ext=x.find('a:ext',NS)
 return tuple(float((off if k<2 else ext).get(a,'0')) if (off if k<2 else ext) is not None else 0 for k,a in enumerate(['x','y','cx','cy']))
def resize_text(el,width,height):
 x=el.find('p:spPr/a:xfrm/a:ext',NS)
 if x is not None:x.set('cx',str(int(width)));x.set('cy',str(int(height)))
 b=el.find('p:txBody/a:bodyPr',NS)
 if b is not None:
  b.set('wrap','square')
  for child in list(b):
   if child.tag in [tag(A,'spAutoFit'),tag(A,'normAutofit')]:b.remove(child)
  E.SubElement(b,tag(A,'noAutofit'))
def image_size(b):
 if b.startswith(b'\x89PNG'):return struct.unpack('>II',b[16:24])
 if b[:2]==b'\xff\xd8':
  i=2
  while i<len(b):
   if b[i]!=255:i+=1;continue
   marker=b[i+1];i+=2
   if marker in [0xd8,0xd9]:continue
   length=int.from_bytes(b[i:i+2],'big')
   if marker in [0xc0,0xc1,0xc2,0xc3,0xc5,0xc6,0xc7,0xc9,0xca,0xcb,0xcd,0xce,0xcf]:return int.from_bytes(b[i+5:i+7],'big'),int.from_bytes(b[i+3:i+5],'big')
   i+=length
 raise ValueError('Use PNG or JPEG evidence.')
def chunks(xs,n):return [xs[i:i+n] for i in range(0,len(xs),n)]
class Deck:
 def __init__(self,template,out,files):
  with zipfile.ZipFile(template) as z:self.source={n:z.read(n) for n in z.namelist()}
  self.parts={k:v for k,v in self.source.items() if not re.match(r'ppt/(slides/|notesSlides/)',k)}
  self.out=Path(out);self.out.mkdir(parents=True,exist_ok=True);self.files=files;self.slides=[];self.warnings=[];self.chart_count=0
 def slide(self,num):
  root=E.fromstring(self.source['ppt/slides/slide%d.xml'%num]);rels=E.fromstring(self.source['ppt/slides/_rels/slide%d.xml.rels'%num])
  for r in list(rels):
   if r.get('Type','').endswith(('/notesSlide','/slide')):rels.remove(r)
  for parent in root.iter():
   for c in list(parent):
    if c.tag in [tag(A,'hlinkClick'),tag(A,'hlinkMouseOver')]:parent.remove(c)
  # Materialize inherited picture transforms without altering their effective placement.
  layoutrel=next((r for r in rels if r.get('Type','').endswith('/slideLayout')),None)
  if layoutrel is not None:
   path=posixpath.normpath(posixpath.join('ppt/slides',layoutrel.get('Target')))
   layout=E.fromstring(self.source[path])
   for pic in root.findall('.//p:pic',NS):
    if pic.find('p:spPr/a:xfrm',NS) is not None:continue
    ph=pic.find('.//p:ph',NS)
    if ph is None:continue
    for candidate in layout.findall('.//p:pic',NS):
     cph=candidate.find('.//p:ph',NS);xf=candidate.find('p:spPr/a:xfrm',NS)
     if cph is not None and cph.get('idx')==ph.get('idx') and xf is not None:
      sp=pic.find('p:spPr',NS)
      if sp is not None:sp.insert(0,copy.deepcopy(xf))
  return root,rels
 def add(self,root,rels):self.slides.append((root,rels))
 def pictures(self,root):
  return [p for p in root.findall('.//p:pic',NS) if 'placeholder' in (p.find('p:nvPicPr/p:cNvPr',NS).get('name','').lower())]
 def fill_image(self,pic,image,rels):
  f=self.files[image['fileId']];b=Path(f['path']).read_bytes();w,h=image_size(b);ext='png' if b.startswith(b'\x89PNG') else 'jpg'
  if w<800 or h<450:self.warnings.append('Low-resolution evidence: '+f['name'])
  name='runway-'+image['fileId']+'.'+ext;self.parts['ppt/media/'+name]=b
  rid='rIdRunway'+str(len(rels)+1);E.SubElement(rels,tag(PK,'Relationship'),{'Id':rid,'Type':R+'/image','Target':'../media/'+name})
  blip=pic.find('p:blipFill/a:blip',NS);blip.set(tag(R,'embed'),rid)
  fill=pic.find('p:blipFill',NS)
  for n in list(fill):
   if n.tag in [tag(A,'srcRect'),tag(A,'stretch'),tag(A,'tile')]:fill.remove(n)
  x,y,cx,cy=geometry(pic)
  if not cx or not cy:
   # Inherited placeholders keep their layout transform; use source dimensions for crop estimation.
   cx,cy=w,h
  crop=image.get('crop',{}) if image.get('mode')=='manual' else {}
  if image.get('mode')=='cover':
   ratio=(cx/cy)/(w/h)
   crop={'left':max(0,(1-ratio)/2),'right':max(0,(1-ratio)/2),'top':max(0,(1-1/ratio)/2),'bottom':max(0,(1-1/ratio)/2)}
  if crop:E.SubElement(fill,tag(A,'srcRect'),{k:str(round(crop.get(name,0)*100000)) for k,name in [('l','left'),('t','top'),('r','right'),('b','bottom')]})
  stretch=E.SubElement(fill,tag(A,'stretch'));rect={}
  if image.get('mode') in ['contain','manual']:
   visible_w=w*(1-crop.get('left',0)-crop.get('right',0));visible_h=h*(1-crop.get('top',0)-crop.get('bottom',0))
   ratio=(cx/cy)/(visible_w/visible_h)
   if ratio>1:rect={'l':str(round((1-1/ratio)*50000)),'r':str(round((1-1/ratio)*50000))}
   else:rect={'t':str(round((1-ratio)*50000)),'b':str(round((1-ratio)*50000))}
  E.SubElement(stretch,tag(A,'fillRect'),rect)
 def hide_picture(self,root,pic):
  for parent in root.iter():
   if pic in list(parent):parent.remove(pic);break
 def headers(self,root,team,market):
  replace_regex(root,r'^SECE\s*\|\s*DA\s*\|','SECE | DA | '+market)
  for s in shapes(root):
   if norm(txt(s)) in ['atl/btl','retail','digital']:set_text(s,team)
 def summary(self,projects,month,missing=None):
  selected=selected_projects(projects,'summary')
  root,rels=self.slide(2);replace(root,'A month execution across five markets','Monthly executive summary')
  names=[];values=[]
  for team in REPORT_TEAMS:
   project=next((p for p in selected if p['team']==team),None)
   names.append(project['data']['title'] if project else team)
   values.append(project['data']['summaryText'] if project else 'Not submitted' if team in (missing or []) else 'No highlight selected')
  replace(root,'Project name',names);replace(root,'Key highlight',values);self.add(root,rels)
 def brief(self,p,team):
  d=p['data'];items=[('Objective',d['goal']),('This month',d['done']),('Outcome',d['conclusion']),('Period',d['start']+' – '+d['end']),('Category',d['category']),('Partner',d['partner']+(' · '+d.get('partnerNote','') if d['partner']=='N/A' else ''))]
  if 'Retail' in d['channels']:items.append(('Retail status',d['retailStatus']+' · '+d['retailStage']))
  budget=d.get('budget',{})
  if budget.get('plan') or budget.get('actual'):items.append(('Budget',str(budget.get('plan',''))+' / '+str(budget.get('actual',''))+' '+budget.get('currency','')))
  # Reuse the four original cards; expand only their invisible text areas inside the existing cards.
  for group in chunks(items,4):
   root,rels=self.slide(13);replace(root,'HEADING',d['title']);self.headers(root,team,d['market']);replace(root,'NEXT MONTH','PROJECT BRIEF')
   replace(root,'PROJECT NAME',[a for a,b in group]);replace(root,'Key activities',[b for a,b in group]);replace(root,'Country',[d['market']]*len(group))
   for s in shapes(root):
    if txt(s) in [b for a,b in group]:resize_text(s,4800000,750000)
   self.add(root,rels)
 def next_steps(self,projects,team='NEXT MONTH'):
  selected=selected_projects(projects,'next')
  root,rels=self.slide(13);replace(root,'HEADING','Next steps')
  names=[];activities=[];countries=[]
  for project in selected:
   d=project['data'];names.append(d['title']);countries.append(d['market'])
   value='\n'.join(step['action']+'\n'+step['owner']+' · '+step['due'] for step in d['steps'])
   if len(value)>150:raise ValueError('Shorten the selected next steps to fit the single final slide: '+d['title'])
   activities.append(value)
  replace(root,'PROJECT NAME',names);replace(root,'Country',countries);replace(root,'Key activities',activities)
  for shape in shapes(root):
   if '\n' in txt(shape):resize_text(shape,4800000,800000)
  self.add(root,rels)
 def project_slide(self,layout,projects,team):
  base={'promo':4,'content':7 if team=='4CA Marketing' else 5,'launch':6,'pipeline':10 if team=='KZ Retail' else 8,'collage':11 if team=='KZ Retail' else 9,'retail':12,'models':3}[layout]
  images=[]
  for p in projects:
   for g in p['data']['groups']:
    for img in g['images']:images.append((p,g,img))
    if layout=='content' and len(g['images'])%2:images.append(None)
  sample,_=self.slide(base);capacity=len(self.pictures(sample))
  # One composer entry produces one project slide. Never add project pages implicitly.
  if capacity and len(images)>capacity:raise ValueError('This layout has room for %d image slots. Choose a larger source layout or separate the projects in the slide composer.'%capacity)
  d=projects[0]['data']
  if layout=='promo' and len(d.get('kpis',[]))>2 and not d.get('editableChart'):raise ValueError('This source layout shows two KPIs. Select the editable KPI chart explicitly to include more metrics.')
  if layout=='launch' and len(d.get('steps',[]))>5:raise ValueError('This source layout shows five activities. Choose a different layout or reduce the activities on this project slide.')
  pages=[images] if capacity else [[]]
  for page,pack in enumerate(pages):
   root,rels=self.slide(base);d=projects[0]['data'];title=d['title'] if len(projects)==1 else 'Monthly activities'
   self.headers(root,team,d['market'] if len(projects)==1 else 'ALL')
   for label in ['Project Name','PROJECT NAME','Launch name','Awareness content','KEY highlights','NAME','Hit models  Supportive Digital Performance']:
    if layout!='pipeline' or norm(label)!='project name':replace(root,label,title)
   replace(root,'Focus products',d.get('productFocus') or d['category']);replace_regex(root,r'^Promo period:',d['start']+' – '+d['end'])
   if layout=='promo':
    labels=[k['name']+' · '+k['unit'] for k in d['kpis'][(page*2):(page*2+2)]];values=[str(k['actual'])+' / '+str(k['plan']) for k in d['kpis'][(page*2):(page*2+2)]]
    replace(root,'KPI',labels);replace(root,'Result',values);replace(root,'*promo mechanics*',[d['goal'],d['done'],d['conclusion']])
   elif layout=='launch':
    replace(root,'Activity name',[s['action'] for s in d['steps'][(page*5):(page*5+5)]]);replace(root,'Description',[s['owner']+' · '+s['due'] for s in d['steps'][(page*5):(page*5+5)]]);replace(root,'Status',['']*5)
   elif layout=='pipeline':
    # Assign cards to the source column positions, never move the four column headings.
    stage_x={'Design':0,'Bidding':1,'Production':2,'Installed':3};cols=[[],[],[],[]]
    for p in projects:cols[stage_x[p['data']['retailStage']]].append(p)
    countries=[s for s in shapes(root) if norm(txt(s))=='country'];names=[s for s in shapes(root) if norm(txt(s))=='project name']
    for s in countries+names:
     x=geometry(s)[0];column=min(range(4),key=lambda i:abs(x-[435291,3204483,5973676,8743634][i]));index=sum(1 for old in (countries if s in countries else names) if old is not s and geometry(old)[0]//100000==x//100000 and geometry(old)[1]<geometry(s)[1]);items=cols[column]
     set_text(s,(items[index]['data']['market'] if s in countries else items[index]['data']['title']) if index<len(items) else '')
    for column,items in enumerate(cols):
     available=sum(1 for s in countries if min(range(4),key=lambda i:abs(geometry(s)[0]-[435291,3204483,5973676,8743634][i]))==column)
     if len(items)>available:raise ValueError('Pipeline column capacity exceeded. Split this slide in the composer.')
   elif layout=='retail':
    replace(root,'DESCRIPTION',d['goal']);seen=set();heads=[];subs=[]
    for p,g,img in pack:
     key=(p['id'],g['id']);heads.append(g['heading'] if key not in seen else '');subs.append(g['subtitle'] if key not in seen else '');seen.add(key)
    replace(root,'ACTIVITY',heads);replace(root,'description',subs)
   elif layout=='models':
    headings=[]
    for p,g,img in pack:
     if g['heading'] not in headings:headings.append(g['heading'])
    replace(root,'Premium',headings[:1]);replace(root,'Step Up',headings[1:2])
   # Spatial filling changes content only, never the XML sibling/z order.
   pics=sorted(self.pictures(root),key=lambda p:(round(geometry(p)[0]/10000),geometry(p)[1]))
   for i,pic in enumerate(pics):
    if i<len(pack) and pack[i] is not None:self.fill_image(pic,pack[i][2],rels)
    else:self.hide_picture(root,pic)
   if layout=='content':
    heads=sorted([s for s in shapes(root) if norm(txt(s))=='content type'],key=lambda s:geometry(s)[0]);subs=sorted([s for s in shapes(root) if norm(txt(s))=='description'],key=lambda s:geometry(s)[0]);seen=set()
    for i,head in enumerate(heads):
     batch=[entry for entry in pack[i*2:i*2+2] if entry is not None];key=(batch[0][0]['id'],batch[0][1]['id']) if batch else None
     set_text(head,batch[0][1]['heading'] if batch and key not in seen else '')
     if i<len(subs):set_text(subs[i],batch[0][1]['subtitle'] if batch and key not in seen else '')
     seen.add(key)
   if layout=='collage':
    caps=[s for s in shapes(root) if norm(txt(s))==norm(title) and s.find('p:txBody',NS) is not None and geometry(s)[2]<3000000]
    caps=sorted(caps,key=lambda s:(round(geometry(s)[0]/10000),geometry(s)[1]));seen=set()
    for i,cap in enumerate(caps):
     entry=pack[i] if i<len(pack) else None;key=(entry[0]['id'],entry[1]['id']) if entry else None
     set_text(cap,(entry[1]['heading']+' · '+entry[1]['subtitle']) if entry and key not in seen else '');seen.add(key)
   self.add(root,rels)
   if d.get('editableChart') and layout=='promo' and page==0:
    chartroot,chartrels=self.slide(4);self.headers(chartroot,team,d['market']);replace(chartroot,'Project Name',d['title']+' · KPI');replace_regex(chartroot,r'^Promo period:',d['start']+' – '+d['end']);replace(chartroot,'KPI',[k['name']+' · '+k['unit'] for k in d['kpis'][:2]]);replace(chartroot,'Result',[str(k['actual'])+' / '+str(k['plan']) for k in d['kpis'][:2]]);replace(chartroot,'*promo mechanics*',['Plan vs actual','','']);chartpics=self.pictures(chartroot)
    for cp in chartpics[1:]:self.hide_picture(chartroot,cp)
    if chartpics:self.add_chart(chartroot,chartpics[0],d,chartrels)
    self.add(chartroot,chartrels)
 def add_chart(self,root,pic,d,rels):
  self.chart_count+=1;n=self.chart_count;x,y,cx,cy=geometry(pic)
  # The evidence slot is reused. The uploaded evidence remains on continuation slides / other slots.
  data=d['kpis'];cx=7107341;chart=E.Element(tag(C,'chartSpace'));E.SubElement(chart,tag(C,'lang'),{'val':'en-US'});ch=E.SubElement(chart,tag(C,'chart'));plot=E.SubElement(ch,tag(C,'plotArea'));E.SubElement(plot,tag(C,'layout'));bar=E.SubElement(plot,tag(C,'barChart'));E.SubElement(bar,tag(C,'barDir'),{'val':'col'});E.SubElement(bar,tag(C,'grouping'),{'val':'clustered'})
  for si,name in enumerate(['Plan','Actual']):
   ser=E.SubElement(bar,tag(C,'ser'));E.SubElement(ser,tag(C,'idx'),{'val':str(si)});E.SubElement(ser,tag(C,'order'),{'val':str(si)});tx=E.SubElement(ser,tag(C,'tx'));E.SubElement(tx,tag(C,'v')).text=name
   series_style=E.SubElement(ser,tag(C,'spPr'));E.SubElement(E.SubElement(series_style,tag(A,'solidFill')),tag(A,'srgbClr'),{'val':'3059A8' if si==0 else '79C8E8'})
   cat=E.SubElement(ser,tag(C,'cat'));ref=E.SubElement(cat,tag(C,'strRef'));E.SubElement(ref,tag(C,'f')).text="Sheet1!$A$2:$A$"+str(len(data)+1);sc=E.SubElement(ref,tag(C,'strCache'));E.SubElement(sc,tag(C,'ptCount'),{'val':str(len(data))})
   for i,k in enumerate(data):pt=E.SubElement(sc,tag(C,'pt'),{'idx':str(i)});E.SubElement(pt,tag(C,'v')).text=k['name']+' ('+k['unit']+')'
   val=E.SubElement(ser,tag(C,'val'));ref=E.SubElement(val,tag(C,'numRef'));column='B' if si==0 else 'C';E.SubElement(ref,tag(C,'f')).text='Sheet1!$'+column+'$2:$'+column+'$'+str(len(data)+1);nc=E.SubElement(ref,tag(C,'numCache'));E.SubElement(nc,tag(C,'formatCode')).text='General';E.SubElement(nc,tag(C,'ptCount'),{'val':str(len(data))})
   for i,k in enumerate(data):pt=E.SubElement(nc,tag(C,'pt'),{'idx':str(i)});E.SubElement(pt,tag(C,'v')).text=str(k['plan' if si==0 else 'actual'])
  for axis in ['1','2']:E.SubElement(bar,tag(C,'axId'),{'val':axis})
  for kind,ident,cross,pos in [('catAx','1','2','b'),('valAx','2','1','l')]:
   ax=E.SubElement(plot,tag(C,kind));E.SubElement(ax,tag(C,'axId'),{'val':ident});scale=E.SubElement(ax,tag(C,'scaling'));E.SubElement(scale,tag(C,'orientation'),{'val':'minMax'});E.SubElement(ax,tag(C,'axPos'),{'val':pos});E.SubElement(ax,tag(C,'crossAx'),{'val':cross});E.SubElement(ax,tag(C,'crosses'),{'val':'autoZero'})
  E.SubElement(ch,tag(C,'plotVisOnly'),{'val':'1'})
  external=E.SubElement(chart,tag(C,'externalData'),{tag(R,'id'):'rIdWorkbook'});E.SubElement(external,tag(C,'autoUpdate'),{'val':'0'})
  chart_style=E.SubElement(chart,tag(C,'spPr'));E.SubElement(E.SubElement(chart_style,tag(A,'solidFill')),tag(A,'srgbClr'),{'val':'030923'})
  label_style=E.SubElement(chart,tag(C,'txPr'));E.SubElement(label_style,tag(A,'bodyPr'));E.SubElement(label_style,tag(A,'lstStyle'));paragraph=E.SubElement(label_style,tag(A,'p'));default=E.SubElement(E.SubElement(paragraph,tag(A,'pPr')),tag(A,'defRPr'),{'sz':'1400'});E.SubElement(E.SubElement(default,tag(A,'solidFill')),tag(A,'srgbClr'),{'val':'FFFFFF'});E.SubElement(default,tag(A,'latin'),{'typeface':'Instrument Sans'});E.SubElement(paragraph,tag(A,'endParaRPr'),{'lang':'en-US'})
  chart.remove(external);chart.append(external)
  self.parts['ppt/charts/runway%d.xml'%n]=xml(chart)
  crels=E.Element(tag(PK,'Relationships'));E.SubElement(crels,tag(PK,'Relationship'),{'Id':'rIdWorkbook','Type':R+'/package','Target':'../embeddings/runway%d.xlsx'%n});self.parts['ppt/charts/_rels/runway%d.xml.rels'%n]=xml(crels)
  self.parts['ppt/embeddings/runway%d.xlsx'%n]=self.workbook(data)
  frame=E.Element(tag(P,'graphicFrame'));nv=E.SubElement(frame,tag(P,'nvGraphicFramePr'));E.SubElement(nv,tag(P,'cNvPr'),{'id':spid(pic),'name':'Editable KPI chart'});E.SubElement(nv,tag(P,'cNvGraphicFramePr'));E.SubElement(nv,tag(P,'nvPr'));tr=E.SubElement(frame,tag(P,'xfrm'));E.SubElement(tr,tag(A,'off'),{'x':str(int(x)),'y':str(int(y))});E.SubElement(tr,tag(A,'ext'),{'cx':str(int(cx)),'cy':str(int(cy))});gr=E.SubElement(frame,tag(A,'graphic'));gd=E.SubElement(gr,tag(A,'graphicData'),{'uri':C});rid='rIdChart'+str(n);E.SubElement(gd,tag(C,'chart'),{tag(R,'id'):rid});E.SubElement(rels,tag(PK,'Relationship'),{'Id':rid,'Type':R+'/chart','Target':'../charts/runway%d.xml'%n})
  for parent in root.iter():
   if pic in list(parent):idx=list(parent).index(pic);parent.remove(pic);parent.insert(idx,frame);break
 def workbook(self,data):
  S='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
  workbook=E.Element(tag(S,'workbook'));sheets=E.SubElement(workbook,tag(S,'sheets'));E.SubElement(sheets,tag(S,'sheet'),{'name':'Sheet1','sheetId':'1',tag(R,'id'):'rId1'})
  sheet=E.Element(tag(S,'worksheet'));rows=E.SubElement(sheet,tag(S,'sheetData'))
  values=[['KPI','Plan','Actual']]+[[k['name']+' ('+k['unit']+')',k['plan'],k['actual']] for k in data]
  for ri,rowvalues in enumerate(values,1):
   row=E.SubElement(rows,tag(S,'row'),{'r':str(ri)})
   for ci,value in enumerate(rowvalues):
    c=E.SubElement(row,tag(S,'c'),{'r':chr(65+ci)+str(ri)})
    if isinstance(value,(int,float)):E.SubElement(c,tag(S,'v')).text=str(value)
    else:c.set('t','inlineStr');E.SubElement(E.SubElement(c,tag(S,'is')),tag(S,'t')).text=str(value)
  wr=E.Element(tag(PK,'Relationships'));E.SubElement(wr,tag(PK,'Relationship'),{'Id':'rId1','Type':R+'/worksheet','Target':'worksheets/sheet1.xml'})
  rr=E.Element(tag(PK,'Relationships'));E.SubElement(rr,tag(PK,'Relationship'),{'Id':'rId1','Type':R+'/officeDocument','Target':'xl/workbook.xml'})
  ct=E.Element(tag(CT,'Types'));E.SubElement(ct,tag(CT,'Default'),{'Extension':'rels','ContentType':'application/vnd.openxmlformats-package.relationships+xml'});E.SubElement(ct,tag(CT,'Default'),{'Extension':'xml','ContentType':'application/xml'});E.SubElement(ct,tag(CT,'Override'),{'PartName':'/xl/workbook.xml','ContentType':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml'});E.SubElement(ct,tag(CT,'Override'),{'PartName':'/xl/worksheets/sheet1.xml','ContentType':'application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml'})
  stream=io.BytesIO()
  with zipfile.ZipFile(stream,'w',zipfile.ZIP_DEFLATED) as z:
   for name,el in [('[Content_Types].xml',ct),('_rels/.rels',rr),('xl/workbook.xml',workbook),('xl/_rels/workbook.xml.rels',wr),('xl/worksheets/sheet1.xml',sheet)]:z.writestr(name,xml(el))
  return stream.getvalue()
 def write(self):
  pres=E.fromstring(self.source['ppt/presentation.xml']);ids=pres.find('p:sldIdLst',NS);ids.clear();pr=E.fromstring(self.source['ppt/_rels/presentation.xml.rels'])
  for r in list(pr):
   if r.get('Type','').endswith('/slide'):pr.remove(r)
  types=E.fromstring(self.source['[Content_Types].xml'])
  for t in list(types):
   if t.get('PartName','').startswith(('/ppt/slides/','/ppt/notesSlides/')):types.remove(t)
  for i,(root,rels) in enumerate(self.slides,1):
   rid='rIdRunwaySlide%d'%i;E.SubElement(ids,tag(P,'sldId'),{'id':str(255+i),tag(R,'id'):rid});E.SubElement(pr,tag(PK,'Relationship'),{'Id':rid,'Type':R+'/slide','Target':'slides/slide%d.xml'%i});E.SubElement(types,tag(CT,'Override'),{'PartName':'/ppt/slides/slide%d.xml'%i,'ContentType':'application/vnd.openxmlformats-officedocument.presentationml.slide+xml'})
   self.parts['ppt/slides/slide%d.xml'%i]=xml(root);self.parts['ppt/slides/_rels/slide%d.xml.rels'%i]=xml(rels)
  if self.chart_count and not any(t.get('Extension')=='xlsx' for t in types):E.SubElement(types,tag(CT,'Default'),{'Extension':'xlsx','ContentType':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'})
  for i in range(1,self.chart_count+1):E.SubElement(types,tag(CT,'Override'),{'PartName':'/ppt/charts/runway%d.xml'%i,'ContentType':'application/vnd.openxmlformats-officedocument.drawingml.chart+xml'})
  self.parts['ppt/presentation.xml']=xml(pres);self.parts['ppt/_rels/presentation.xml.rels']=xml(pr);self.parts['[Content_Types].xml']=xml(types)
  with zipfile.ZipFile(self.out/'report.pptx','w',zipfile.ZIP_DEFLATED) as z:
   for name,data in self.parts.items():z.writestr(name,data)
  return len(self.slides)

REPORT_TEAMS=['KZ ATL/BTL','4CA Marketing','KZ Retail']
def selected_projects(projects,flag):
 selected=[]
 for team in REPORT_TEAMS:
  matches=[p for p in projects if p.get('team')==team and p['data'].get(flag)]
  if len(matches)>1:raise ValueError('Select only one main project for '+flag+' in '+team)
  selected.extend(matches)
 return selected

def month_label(month):
 names=['January','February','March','April','May','June','July','August','September','October','November','December']
 return names[int(month[5:7])-1]+' '+month[:4]

def result_slides(out,count):
 # Reuse the rendered project slides in their actual PPTX order, including explicit continuations/charts.
 result=[]
 for number in range(3,count):
  exact=Path(out)/'rendered'/('slide-%d.png'%number)
  path=exact if exact.exists() else Path(out)/'preview'/('slide-%d.svg'%number)
  mime='image/png' if exact.exists() else 'image/svg+xml'
  result.append((number,'data:'+mime+';base64,'+base64.b64encode(path.read_bytes()).decode()))
 return result

def html_report(payload,email=False,slides=()):
 esc=lambda s:html.escape(str(s));projects=payload['projects'];missing=payload.get('missing',[]);summary=selected_projects(projects,'summary');steps=[(p,s) for p in selected_projects(projects,'next') for s in p['data']['steps']]
 # Reuse the actual summary slide's glow asset, theme colours and panel treatment.
 here=Path(__file__).resolve().parent
 with zipfile.ZipFile(here/'templates/high-technology-gsl.pptx') as source:
  background=base64.b64encode(source.read('ppt/media/image1.png')).decode()
 font=base64.b64encode((here/'fonts/instrumentsans/InstrumentSans[wdth,wght].ttf').read_bytes()).decode()
 font_style='<style>@font-face{font-family:"Instrument Sans";font-style:normal;font-weight:400 700;src:url(data:font/ttf;base64,'+font+') format("truetype")}</style>'
 style='font-family:Instrument Sans,Arial,sans-serif;color:#FFFFFF;background-color:#000000;background-image:url(data:image/png;base64,'+background+');background-repeat:no-repeat;background-position:-138px 106px;background-size:822px 550px;max-width:960px;margin:auto;padding:28px;'
 panel='border-collapse:separate;border-spacing:0;width:100%;font-size:16px;background-color:#080E20;background-image:linear-gradient(315deg,rgba(64,117,245,0.13),rgba(217,227,253,0));border:1px solid rgba(38,38,38,0.5);border-radius:10px;box-shadow:0 0 48px rgba(0,0,0,0.74);'
 cell='padding:12px 14px;border-bottom:1px solid rgba(197,217,254,0.18);text-align:left;vertical-align:top;color:#FFFFFF;'
 def row(values,head=False):
  cell_style=cell+('color:#C5D9FE;font-weight:600;' if head else '')
  return '<tr>'+''.join('<%s style="%s">%s</%s>'%('th' if head else 'td',cell_style,esc(v),'th' if head else 'td') for v in values)+'</tr>'
 content=font_style+'<div style="'+style+'"><h1 style="font-size:44px;line-height:1.12;font-weight:600;letter-spacing:-1.5px;margin:0 0 24px">Marketing report · '+esc(month_label(payload['month']))+'</h1>'
 if missing:content+='<p style="color:#F8CA7C">Incomplete report · Missing: '+esc(', '.join(missing))+'</p>'
 content+='<section data-highlights="summary"><h2 style="font-size:28px;font-weight:500;color:#FFFFFF;margin:22px 0 14px">Executive summary</h2><table style="'+panel+'">'+row(['Team / project','This month','Main result'],True)
 for p in summary:content+=row([p['team']+' / '+p['data']['title'],p['data']['done'],p['data']['summaryText']])
 content+='</table></section><section data-main-results="true"><h2 style="font-size:28px;font-weight:500;color:#FFFFFF;margin:28px 0 14px">Main results</h2>'
 for number,uri in slides:
  content+='<figure data-slide="'+str(number)+'" style="margin:0 0 24px"><figcaption style="font-size:13px;color:#C5D9FE;margin:0 0 8px">Slide '+str(number)+'</figcaption><img src="'+uri+'" alt="Project slide '+str(number)+'" width="904" style="display:block;width:100%;max-width:100%;height:auto;border:1px solid #23365E;border-radius:6px"></figure>'
 content+='</section><section data-highlights="next"><h2 style="font-size:28px;font-weight:500;color:#C5D9FE;margin:28px 0 14px">Next steps</h2><table style="'+panel+'">'+row(['Project','Action','Owner','Due'],True)
 for p,s in steps:content+=row([p['data']['title'],s['action'],s['owner'],s['due']])
 content+='</table></section><p style="font-size:11px;color:#C5D9FE;margin-top:20px">Source versions: '+esc(', '.join(payload.get('sourceVersions',[])))+'</p></div>'
 return content if email else '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Marketing report</title></head><body style="margin:0;background-color:#000000;color:#FFFFFF">'+content+'</body></html>'
def main():
 request=json.load(sys.stdin);payload=request['snapshot'];out=Path(request['out'])
 if '--html-only' in sys.argv:
  count=json.loads((out/'manifest.json').read_text())['slides']
  slides=result_slides(out,count)
  (out/'summary.html').write_text(html_report(payload,slides=slides),encoding='utf-8');(out/'email.html').write_text(html_report(payload,True,slides),encoding='utf-8')
  return
 deck=Deck(request['template'],out,request['files']);cover_month=month_label(payload['month'])
 root,rels=deck.slide(1);replace(root,'October 2026',cover_month);deck.add(root,rels);deck.summary(payload['projects'],payload['month'],payload.get('missing',[]))
 projects={p['id']:p for p in payload['projects']}
 for report in payload['reports']:
  for plan in report['plan']:deck.project_slide(plan['layout'],[projects[id] for id in plan['projectIds']],report['team'])
 deck.next_steps(payload['projects']);count=deck.write()
 from preview_pptx import main as preview
 from contextlib import redirect_stdout
 with redirect_stdout(io.StringIO()):preview(str(out/'report.pptx'),str(out/'preview'),str(Path(__file__).resolve().parent/'fonts/instrumentsans/InstrumentSans[wdth,wght].ttf'))
 slides=result_slides(out,count)
 (out/'summary.html').write_text(html_report(payload,slides=slides),encoding='utf-8');(out/'email.html').write_text(html_report(payload,True,slides),encoding='utf-8')
 (out/'manifest.json').write_text(json.dumps({'slides':count,'warnings':list(dict.fromkeys(deck.warnings)),'exactPreview':False,'template':'High Technology - GSL.pptx','templateVersion':'gsl-2026-11-04'},indent=2))
 print(json.dumps({'slides':count,'warnings':list(dict.fromkeys(deck.warnings))}))
if __name__=='__main__':main()
