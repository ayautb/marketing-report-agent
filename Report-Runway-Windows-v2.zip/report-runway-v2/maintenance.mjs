import {DatabaseSync} from 'node:sqlite';
import {resolve,join,dirname} from 'node:path';import {fileURLToPath} from 'node:url';
import {mkdirSync,cpSync,rmSync,readdirSync,statSync} from 'node:fs';
const root=resolve(process.env.DATA_DIR??join(dirname(fileURLToPath(import.meta.url)),'data'));
const action=process.argv[2];
if(action==='backup'){
 const target=resolve(process.argv[3]??'');if(!process.argv[3]||target===root||target.startsWith(root+'/'))throw new Error('Choose a new backup directory outside DATA_DIR. Stop the server first.');
 mkdirSync(target,{recursive:false,mode:0o700});cpSync(root,join(target,'data'),{recursive:true,errorOnExist:true,force:false});console.log('Backup copied. Verify recovery in a separate test directory.');
}else if(action==='purge'){
 const db=new DatabaseSync(join(root,'runway.sqlite'));db.exec('PRAGMA foreign_keys=ON');const cutoff=new Date(Date.now()-365*86400000).toISOString(),month=cutoff.slice(0,7);
 const builds=db.prepare('SELECT id FROM builds_v2 WHERE expires_at<?').all(new Date().toISOString());const updates=db.prepare('SELECT id FROM updates_v2 WHERE month<?').all(month);
 console.log(JSON.stringify({expiredBuilds:builds.length,oldMonthlyUpdates:updates.length,cutoff,apply:process.argv.includes('--apply')}));
 if(process.argv.includes('--apply')){
  db.exec('BEGIN');try{
   for(const b of builds){db.prepare('DELETE FROM submissions_v2 WHERE build_id=?').run(b.id);db.prepare('DELETE FROM version_files_v2 WHERE build_id=?').run(b.id);db.prepare('DELETE FROM builds_v2 WHERE id=?').run(b.id);}
   for(const u of updates){db.prepare('DELETE FROM update_files_v2 WHERE update_id=?').run(u.id);db.prepare('DELETE FROM updates_v2 WHERE id=?').run(u.id);}
   db.prepare('DELETE FROM plans_v2 WHERE month<?').run(month);db.prepare('DELETE FROM projects_v2 WHERE NOT EXISTS (SELECT 1 FROM updates_v2 u WHERE u.project_id=projects_v2.id)').run();
   db.prepare('DELETE FROM audit WHERE at<?').run(cutoff.replace('T',' ').slice(0,19));db.exec('COMMIT');
  }catch(e){db.exec('ROLLBACK');throw e;}
  for(const b of builds)rmSync(join(root,'builds',b.id),{recursive:true,force:true});
  const orphaned=db.prepare("SELECT f.id,f.stored_name FROM files f WHERE f.created_at<datetime('now','-1 day') AND NOT EXISTS (SELECT 1 FROM update_files_v2 u WHERE u.file_id=f.id) AND NOT EXISTS (SELECT 1 FROM version_files_v2 v WHERE v.file_id=f.id)").all();
  for(const f of orphaned){db.prepare('DELETE FROM files WHERE id=?').run(f.id);rmSync(join(root,'files',f.stored_name),{force:true});}
  const live=new Set(db.prepare('SELECT stored_name FROM files').all().map(f=>f.stored_name));
  for(const name of readdirSync(join(root,'files'))){const path=join(root,'files',name);if(!live.has(name)&&statSync(path).mtimeMs<Date.now()-86400000)rmSync(path,{force:true});}
  db.prepare("DELETE FROM sessions WHERE expires<?").run(Date.now());console.log('Expired versions and unreferenced files removed.');
 }
 db.close();
}else{console.log('Stop the server first. Commands: node maintenance.mjs backup /absolute/new-directory | node maintenance.mjs purge [--apply]');}
