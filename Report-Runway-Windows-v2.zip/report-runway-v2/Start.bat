@echo off
setlocal DisableDelayedExpansion
pushd "%~dp0"
if errorlevel 1 goto folder_error
where node.exe >nul 2>&1
if errorlevel 1 goto node_error
node.exe "%~dp0windows-launcher.mjs"
set "runway_exit=%errorlevel%"
popd
if not "%runway_exit%"=="0" pause
exit /b %runway_exit%

:node_error
echo Node.js 24 or later is required.
echo Ask IT to install Node.js, then open Start.bat again.
echo If Node.js was just installed, close this window and reopen Start.bat.
popd
pause
exit /b 1

:folder_error
echo Extract the entire ZIP to a local folder, then open Start.bat.
pause
exit /b 1
