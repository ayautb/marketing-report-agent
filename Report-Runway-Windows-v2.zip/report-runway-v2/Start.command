#!/bin/zsh
cd -- "${0:A:h}"
runway_node="$(command -v node 2>/dev/null)"
if [[ -z "$runway_node" && -x /Applications/ChatGPT.app/Contents/Resources/cua_node/bin/node ]]; then
  runway_node=/Applications/ChatGPT.app/Contents/Resources/cua_node/bin/node
fi
if [[ -z "$runway_node" ]]; then
  print 'Node.js 24 or later is needed on the server. No LibreOffice is required.'
  read '?Press Enter to close.'
  exit 1
fi
"$runway_node" -e 'if (Number(process.versions.node.split(".")[0]) < 24) { console.error("Node.js 24 or later is required."); process.exit(1); }' || exit 1
if ! command -v python3 >/dev/null 2>&1; then
  print 'Python 3.9+ is required on the application server for PowerPoint export. No LibreOffice is required.'
  read '?Press Enter to close.'
  exit 1
fi
print 'Open http://127.0.0.1:4317 in your browser. Keep this window open. Ctrl+C stops the app.'
"$runway_node" server.mjs
