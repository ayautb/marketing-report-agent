import { createApplication } from './server.mjs';
if(process.argv[2]!=='create-user') { console.error('Usage: node manage.mjs create-user < account.json'); process.exit(1); }
let input='';
for await (const chunk of process.stdin) { input+=chunk; if(input.length>8000) throw new Error('Account input too large'); }
const app=createApplication();
try { const user=await app.createUser(JSON.parse(input)); console.log(JSON.stringify(user)); }
catch(error) { console.error(error.message); process.exitCode=1; }
finally { app.db.close(); }
