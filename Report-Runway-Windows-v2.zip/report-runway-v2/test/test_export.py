import unittest,tempfile,subprocess,json,zipfile,base64,io,posixpath,copy
from pathlib import Path
import xml.etree.ElementTree as E
from html.parser import HTMLParser
ROOT=Path(__file__).resolve().parents[1]
N={'p':'http://schemas.openxmlformats.org/presentationml/2006/main','a':'http://schemas.openxmlformats.org/drawingml/2006/main','c':'http://schemas.openxmlformats.org/drawingml/2006/chart'}
PNG=base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9Y9ZlWQAAAAASUVORK5CYII=')
def data(title,groups):return {'title':title,'market':'KZ','category':'Laundry','partner':'Partner','goal':'Objective','start':'2026-11-01','end':'2026-11-20','channels':['Digital'],'done':'Monthly activity','conclusion':'Supported result','groups':groups,'kpis':[],'steps':[{'action':'Next action','owner':'Manager','due':'2026-12-01'}],'summary':True,'summaryText':'Main result','next':True,'editableChart':False}
class Exports(unittest.TestCase):
 def export(self,projects,plan,reports=None,missing=None):
  temp=tempfile.TemporaryDirectory();self.addCleanup(temp.cleanup);out=Path(temp.name);files={}
  for p in projects:
   p.setdefault('team','KZ ATL/BTL')
   for g in p['data']['groups']:
    for im in g['images']:
     image=out/(im['fileId']+'.png');image.write_bytes(PNG);files[im['fileId']]={'path':str(image),'name':image.name}
  req={'template':str(ROOT/'templates/high-technology-gsl.pptx'),'out':str(out),'files':files,'snapshot':{'month':'2026-11','projects':projects,'reports':reports if reports is not None else [{'team':'KZ ATL/BTL','projectIds':[p['id'] for p in projects],'plan':plan}],'sourceVersions':[],'missing':missing or []}}
  result=subprocess.run(['python3',str(ROOT/'export_report.py')],input=json.dumps(req),text=True,capture_output=True)
  if result.returncode:raise AssertionError(result.stderr)
  return zipfile.ZipFile(out/'report.pptx'),out
 def group(self,name,n,start=0):return {'id':name,'heading':name,'subtitle':name+' subtitle','images':[{'fileId':'image'+str(i),'mode':'contain','crop':{}} for i in range(start,start+n)]}
 def test_four_plus_two_grouped_images_preserve_source_layers_and_all_evidence(self):
  p=[{'id':'p1','data':data('First project',[self.group('Group A',4)])},{'id':'p2','data':{**data('Second project',[self.group('Group B',2,4)]),'summary':False,'next':False}}];z,out=self.export(p,[{'layout':'content','projectIds':['p1','p2']}]);self.addCleanup(z.close)
  content=E.fromstring(z.read('ppt/slides/slide3.xml'));texts=[''.join(n.text or '' for n in shape.findall('.//a:t',N)).strip() for shape in content.findall('.//p:sp',N)];self.assertEqual(texts.count('Group A'),1);self.assertEqual(texts.count('Group B'),1)
  self.assertEqual(len([n for n in z.namelist() if n.startswith('ppt/media/runway-')]),6)
  with zipfile.ZipFile(ROOT/'templates/high-technology-gsl.pptx') as source:
   original=E.fromstring(source.read('ppt/slides/slide5.xml'))
   ids=lambda root:[e.get('id') for e in root.findall('.//p:cNvPr',N)]
   self.assertEqual(ids(original),ids(content))
 def test_native_chart_has_editable_workbook_and_does_not_replace_evidence(self):
  d=data('KPI project',[self.group('Evidence',3)]);d['kpis']=[{'name':'Registrations','plan':800,'actual':915,'unit':'users'},{'name':'Demos','plan':500,'actual':650,'unit':'sessions'},{'name':'Reach','plan':1200,'actual':1800,'unit':'people'}];d['editableChart']=True
  z,out=self.export([{'id':'p1','data':d}],[{'layout':'promo','projectIds':['p1']}]);self.addCleanup(z.close)
  self.assertIn('ppt/charts/runway1.xml',z.namelist());self.assertIn('ppt/embeddings/runway1.xlsx',z.namelist())
  with zipfile.ZipFile(io.BytesIO(z.read('ppt/embeddings/runway1.xlsx'))) as workbook:
   self.assertIsNone(workbook.testzip());self.assertIn(b'915',workbook.read('xl/worksheets/sheet1.xml'))
  text=' '.join(''.join(E.fromstring(z.read(n)).itertext()) for n in z.namelist() if (n.startswith('ppt/slides/slide') or n.startswith('ppt/charts/runway')) and n.endswith('.xml'))
  self.assertIn('1800',text);self.assertEqual(len([n for n in z.namelist() if n.startswith('ppt/media/runway-')]),3)
 def test_every_internal_relationship_target_exists(self):
  z,out=self.export([{'id':'p1','data':data('Project',[self.group('Evidence',1)])}],[{'layout':'retail','projectIds':['p1']}]);self.addCleanup(z.close)
  names=set(z.namelist())
  for name in names:
   if not name.endswith('.rels'):continue
   base=posixpath.dirname(posixpath.dirname(name)) if name!='_rels/.rels' else ''
   for rel in E.fromstring(z.read(name)):
    if rel.get('TargetMode')=='External':continue
    target=rel.get('Target','').split('#')[0];target=target.lstrip('/') if target.startswith('/') else posixpath.normpath(posixpath.join(base,target))
    self.assertIn(target,names,(name,target))
 def test_one_planned_project_slide_has_no_automatic_brief_or_kpi_slides(self):
  d=data('Single project',[self.group('Evidence',1)]);d['summary']=False;d['next']=False;d['kpis']=[{'name':'Registrations','plan':800,'actual':915,'unit':'users'}]
  z,out=self.export([{'id':'p1','data':d}],[{'layout':'content','projectIds':['p1']}]);self.addCleanup(z.close)
  slides=[n for n in z.namelist() if n.startswith('ppt/slides/slide') and n.endswith('.xml')]
  self.assertEqual(len(slides),4) # Cover + shared summary + exactly one project slide + shared next steps.
  text=' '.join(''.join(E.fromstring(z.read(n)).itertext()) for n in slides)
  self.assertNotIn('PROJECT BRIEF',text)
  with zipfile.ZipFile(ROOT/'templates/high-technology-gsl.pptx') as source:
   before=E.fromstring(source.read('ppt/slides/slide5.xml'));after=E.fromstring(z.read('ppt/slides/slide3.xml'))
   ids=lambda root:[e.get('id') for e in root.findall('.//p:sp/p:nvSpPr/p:cNvPr',N)]
   self.assertEqual(ids(before),ids(after))
 def test_explicit_second_plan_entry_is_preserved(self):
  d=data('Single project',[self.group('Evidence',1)]);d['summary']=False;d['next']=False
  z,out=self.export([{'id':'p1','data':d}],[{'layout':'content','projectIds':['p1']},{'layout':'collage','projectIds':['p1']}]);self.addCleanup(z.close)
  self.assertEqual(len([n for n in z.namelist() if n.startswith('ppt/slides/slide') and n.endswith('.xml')]),5)
 def test_cover_month_is_english_month_name_and_year(self):
  z,out=self.export([{'id':'p1','data':data('Project',[self.group('Evidence',1)])}],[{'layout':'content','projectIds':['p1']}]);self.addCleanup(z.close)
  cover=''.join(E.fromstring(z.read('ppt/slides/slide1.xml')).itertext())
  self.assertIn('November 2026',cover);self.assertNotIn('2026-11',cover)
 def test_html_uses_original_glow_font_and_dark_theme_for_file_and_email(self):
  z,out=self.export([{'id':'p1','data':data('Project',[self.group('Evidence',1)])}],[{'layout':'content','projectIds':['p1']}]);self.addCleanup(z.close)
  with zipfile.ZipFile(ROOT/'templates/high-technology-gsl.pptx') as source:glow=base64.b64encode(source.read('ppt/media/image1.png')).decode()
  for name in ['summary.html','email.html']:
   page=(out/name).read_text()
   self.assertIn('background-color:#000000',page);self.assertIn('Instrument Sans',page);self.assertIn('linear-gradient(315deg',page);self.assertIn(glow,page)
   self.assertEqual(page.count('<table '),2);self.assertIn('Monthly activity',page);self.assertIn('Main result',page);self.assertIn('Next action',page)
 def fixture_three_teams(self):
  teams=['KZ ATL/BTL','4CA Marketing','KZ Retail'];projects=[];reports=[]
  for i,team in enumerate(teams):
   ids=[]
   for j in range(2):
    ident='p%d%d'%(i,j);d=data('Project '+ident,[self.group('Evidence '+ident,1,i*2+j)]);d.update(summary=j==0,next=j==0,summaryText='Result '+ident,steps=[{'action':'Action '+ident,'owner':team,'due':'2026-12-01'}]);projects.append({'id':ident,'team':team,'data':d});ids.append(ident)
   reports.append({'team':team,'projectIds':ids,'plan':[{'layout':'collage' if i==2 else 'content','projectIds':[ident]} for ident in ids]})
  return projects,reports
 def slide_text(self,z,number):return ''.join(E.fromstring(z.read('ppt/slides/slide%d.xml'%number)).itertext())
 def test_shared_highlights_are_only_second_and_last_slides(self):
  projects,reports=self.fixture_three_teams();z,out=self.export(projects,[],reports);self.addCleanup(z.close)
  self.assertEqual(len([n for n in z.namelist() if re_slide(n)]),9)
  self.assertIn('Monthly executive summary',self.slide_text(z,2));self.assertIn('Next steps',self.slide_text(z,9))
  for p in projects:
   for number in [2,9]:self.assertEqual(p['data']['title'] in self.slide_text(z,number),p['data']['summary'])
  for number in range(3,9):self.assertNotIn('Monthly executive summary',self.slide_text(z,number));self.assertNotIn('Next steps',self.slide_text(z,number))
 def test_highlight_changes_leave_project_slide_bytes_and_order_unchanged(self):
  projects,reports=self.fixture_three_teams();z,out=self.export(projects,[],reports);self.addCleanup(z.close)
  changed=copy.deepcopy(projects);changed[0]['data']['summary']=False;changed[1]['data']['summary']=True;z2,out2=self.export(changed,[],reports);self.addCleanup(z2.close)
  self.assertNotEqual(z.read('ppt/slides/slide2.xml'),z2.read('ppt/slides/slide2.xml'))
  for number in [1,*range(3,10)]:self.assertEqual(z.read('ppt/slides/slide%d.xml'%number),z2.read('ppt/slides/slide%d.xml'%number))
 def test_missing_team_is_marked_without_adding_another_summary_slide(self):
  projects,reports=self.fixture_three_teams();projects=projects[:4];reports=reports[:2];z,out=self.export(projects,[],reports,['KZ Retail']);self.addCleanup(z.close)
  self.assertEqual(len([n for n in z.namelist() if re_slide(n)]),7)
  self.assertIn('Not submitted',self.slide_text(z,2));self.assertIn('KZ Retail',self.slide_text(z,2));self.assertIn('Next steps',self.slide_text(z,7))
 def test_html_includes_all_actual_project_slides_between_shared_highlights(self):
  projects,reports=self.fixture_three_teams();z,out=self.export(projects,[],reports);self.addCleanup(z.close)
  class Images(HTMLParser):
   def __init__(self):super().__init__();self.images=[];self.slides=[]
   def handle_starttag(self,tag,attrs):
    a=dict(attrs)
    if tag=='img':self.images.append(a['src'])
    if tag=='figure':self.slides.append(int(a['data-slide']))
  for name in ['summary.html','email.html']:
   page=(out/name).read_text();parsed=Images();parsed.feed(page)
   self.assertEqual(parsed.slides,list(range(3,9)));self.assertEqual(len(parsed.images),6)
   self.assertLess(page.index('Executive summary</h2>'),page.index('Main results</h2>'));self.assertLess(page.index('Main results</h2>'),page.index('Next steps</h2>'))
   self.assertIn('Marketing report · November 2026',page)
   for number,uri in zip(parsed.slides,parsed.images):self.assertEqual(base64.b64decode(uri.split(',',1)[1]),(out/'preview'/('slide-%d.svg'%number)).read_bytes())
  # Once the trusted renderer has run, HTML must use its exact PNGs rather than the SVG fallback.
  rendered=out/'rendered';rendered.mkdir()
  for number in range(1,10):(rendered/('slide-%d.png'%number)).write_bytes(PNG)
  request={'snapshot':{'month':'2026-11','projects':projects,'reports':reports,'sourceVersions':[]},'out':str(out)}
  run=subprocess.run(['python3',str(ROOT/'export_report.py'),'--html-only'],input=json.dumps(request),text=True,capture_output=True);self.assertEqual(run.returncode,0,run.stderr)
  parsed=Images();parsed.feed((out/'summary.html').read_text());self.assertEqual(len(parsed.images),6)
  for uri in parsed.images:self.assertTrue(uri.startswith('data:image/png;base64,'));self.assertEqual(base64.b64decode(uri.split(',',1)[1]),PNG)

def re_slide(name):return name.startswith('ppt/slides/slide') and name.endswith('.xml')
if __name__=='__main__':unittest.main()
